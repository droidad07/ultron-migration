# MEMORY.md

## General
- Gemini CLI installed as a standalone JS file at `/home/arpanbhavsar07/.openclaw/workspace/gemini.js` (v0.27.3).
- To run it, use: `node /home/arpanbhavsar07/.openclaw/workspace/gemini.js [command]`
- User preference: Do not send the entire repository in LLM requests. Use specific file paths or narrow context.
