---
name: custom-skill
description: A template for creating custom skills with placeholder resources. Use this as a starting point for building specialized agent capabilities.
---

# Custom Skill

## Overview
This is a baseline custom skill template. It provides the necessary structure to build out more complex workflows, scripts, and references.

## Getting Started
1. **Define Capabilities**: Decide what specific tasks this skill should handle.
2. **Add Scripts**: Place automation or processing logic in `scripts/`.
3. **Add References**: Put detailed documentation or schemas in `references/`.
4. **Add Assets**: Include templates or boilerplate in `assets/`.

## Workflow
- Identify the user's intent.
- Reference the appropriate script or documentation.
- Execute and provide the result.
