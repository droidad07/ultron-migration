---
name: lecture-architect
description: Comprehensive lecture presentation builder. Use to research topics, generate structured slide content (60-70 slides), and render them into PDF or PPTX using Marp. Ideal for long-form (4+ hour) academic or technical lectures.
---

# Lecture Architect Skill

## Research & Development Protocol (File-First Architecture)

To avoid API quota exhaustion (429 errors), all research and construction must follow the **Stateless Research Protocol**:

1.  **File-Based Intelligence:** Never dump raw research into the chat. Write all findings, technical specifications, and raw data directly to `lectures/research/<topic>_raw.json` or `.md`.
2.  **Segmented Construction:** Build lectures in "Chapters" (10-15 slides each). 
3.  **Checkpointing:** After completing a chapter, write a brief summary to `lectures/research/progress.json`. If the context exceeds 500k tokens (check via 📊 session_status), request a session reset.
4.  **Native Rendering:** Use `node lectures/scripts/render_pptx.js <input_json>` for all outputs. Ensure JSON contains high-fidelity speaker notes and technical bullet points.

## Workflow

- **Phase 1: Blueprinting:** Research the technical hierarchy and write the master outline to `lectures/research/blueprint.md`.
- **Phase 2: Chapter Drafting:** Generate slide content for a single chapter and save as `lectures/output/staging_ch<X>.json`.
- **Phase 3: Synthesis:** Run the rendering engine and present the resulting `.pptx` to Sir.
- **Phase 4: Cleanup:** Archive raw logs and keep the workspace pristine.

## Style Preferences (The "Sir" / Jarvis Standard)

- **Tone:** Sophisticated, human-centric, first-person narrative (Jarvis Protocol).
- **Slide Detail:** High-density, comprehensive study material for students with zero prior background.
- **Notes Format:** First-person explanations in clean bullet points; no instructional prompts (e.g., no "Ask" or "Explain").
- **Pedagogy:** Use analogies (e.g., Neighborhood Watch, Global Library) and include "Challenge/Solution" slides at the end of each chapter.
