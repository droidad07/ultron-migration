---
name: supabase
description: Integration with Supabase for backend services including database management, authentication, storage, and edge functions. Use when a user needs to connect applications to Supabase, perform CRUD operations, manage users/auth flows, or interact with Supabase storage and functions via the CLI or SDKs.
---

# Supabase Skill

This skill provides workflows and patterns for integrating Supabase into your projects.

## Core Workflows

### 1. Initialize Supabase in Project

For JavaScript/TypeScript projects:
```bash
npm install @supabase/supabase-js
```

Initialization pattern:
```javascript
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://your-project.supabase.co'
const supabaseKey = process.env.SUPABASE_KEY
const supabase = createClient(supabaseUrl, supabaseKey)
```

### 2. Database Operations (CRUD)

- **Select**: `const { data, error } = await supabase.from('table').select('*').eq('id', 1)`
- **Insert**: `const { error } = await supabase.from('table').insert({ name: 'New Item' })`
- **Update**: `const { error } = await supabase.from('table').update({ name: 'Updated' }).eq('id', 1)`
- **Delete**: `const { error } = await supabase.from('table').delete().eq('id', 1)`

### 3. Authentication

- **Sign Up**: `await supabase.auth.signUp({ email, password })`
- **Sign In**: `await supabase.auth.signInWithPassword({ email, password })`
- **Sign Out**: `await supabase.auth.signOut()`

## Reference Files

- [API_CHEATSHEET.md](references/API_CHEATSHEET.md): Quick reference for common SDK methods.
- [CLI_GUIDE.md](references/CLI_GUIDE.md): Guide for using the Supabase CLI for migrations and local development.
- [FUNCTIONS_AND_SQL.md](references/FUNCTIONS_AND_SQL.md): Workflows for Edge Functions and common SQL/RLS patterns.

## Best Practices

- Use environment variables for API keys.
- Prefer `maybeSingle()` when expecting zero or one result to avoid errors.
- Always check the `error` object returned from Supabase calls.
