# Supabase API Cheatsheet

## Database (PostgREST)

### Basic Querying
```javascript
// Select specific columns
.select('name, age')

// Filter with logical OR
.or('id.eq.1,name.eq.Han')

// Ordering
.order('id', { ascending: false })

// Pagination
.range(0, 9) // First 10 items
```

### Filters
- `.eq('column', 'value')` - Equals
- `.neq('column', 'value')` - Not equals
- `.gt('column', 'value')` - Greater than
- `.lt('column', 'value')` - Less than
- `.like('column', '%pattern%')` - Pattern matching
- `.ilike('column', '%pattern%')` - Case-insensitive pattern matching
- `.is('column', null)` - Is null/true/false
- `.in('column', ['val1', 'val2'])` - Contained in array

## Storage

### Buckets
```javascript
// List buckets
const { data, error } = await supabase.storage.listBuckets()

// Upload file
const { data, error } = await supabase.storage.from('avatars').upload('public/avatar1.png', file)
```

## Functions
```javascript
// Call Edge Function
const { data, error } = await supabase.functions.invoke('hello-world', {
  body: { name: 'Functions' },
})
```
