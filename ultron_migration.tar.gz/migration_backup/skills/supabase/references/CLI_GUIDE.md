# Supabase CLI Guide

## Installation
```bash
npm install supabase --save-dev
```

## Local Development
```bash
# Initialize supabase in your project
npx supabase init

# Start local supabase stack (Docker required)
npx supabase start

# Stop local stack
npx supabase stop
```

## Database Migrations
```bash
# Create a new migration file
npx supabase migration new migration_name

# Apply migrations to local database
npx supabase db reset

# Push migrations to remote project
npx supabase db push
```

## Link Project
```bash
npx supabase link --project-ref your-project-ref
```
