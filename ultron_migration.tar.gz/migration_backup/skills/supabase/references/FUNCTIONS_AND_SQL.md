# Supabase Edge Functions & SQL Workflows

## Edge Functions

### Development
```bash
# Create a new function
npx supabase functions new <function-name>

# Serve locally
npx supabase functions serve <function-name> --no-verify-jwt

# Deploy to production
npx supabase functions deploy <function-name> --no-verify-jwt
```

### Invocation Pattern (Client Side)
```javascript
const { data, error } = await supabase.functions.invoke('hello-world', {
  body: { name: 'Functions' },
})
```

## SQL Snippets & DDL

### Table Creation
```sql
create table public.profiles (
  id uuid references auth.users not null primary key,
  updated_at timestamp with time zone,
  username text unique,
  full_name text,
  avatar_url text,
  website text,

  constraint username_length check (char_length(username) >= 3)
);
```

### Row Level Security (RLS)
```sql
-- Enable RLS
alter table public.profiles enable row level security;

-- Create policy
create policy "Public profiles are viewable by everyone."
  on profiles for select
  using ( true );

create policy "Users can insert their own profile."
  on profiles for insert
  with check ( auth.uid() = id );
```

### Stored Procedures (RPC)
```sql
create or replace function hello_world()
returns text as $$
  select 'hello world';
$$ language sql;
```
