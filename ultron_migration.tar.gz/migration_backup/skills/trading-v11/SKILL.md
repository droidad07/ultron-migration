---
name: trading-v11
description: Advanced Stock Trading Skill (v11 Precision Lock). High-efficiency momentum trading with ATR stops and 20/80 profit harvesting.
---

# Trading v11 Skill

## Overview
This skill contains the complete v11 trading ecosystem, moved from the root workspace for better organization.

## Structure
- `scripts/`: Active backtest engines and strategy logic.
- `reports/`: Historical simulation CSVs and PnL ledgers.
- `references/`: Database utilities, diagnostic tools, and schema definitions.

## Primary Engine
The current gold standard is `scripts/backtest_2024_v11.js`.

## Standard Reporting Protocol
When delivering backtest results, always use the following "Ecosystem Status" structure:
1. **Starting State:** Initial capital, starting positions, and starting reserve.
2. **Ending Ecosystem:** Final values for the active portfolio vs. the harvested reserve.
3. **Active Trading Portfolio:** The current liquid value available for the next trade.
4. **Total Realized Cash Reserve:** The total "banked" profit from the 20/80 harvesting protocol.
5. **Strategic Observations:** High-level diagnostic of what worked (tickers/regimes).
