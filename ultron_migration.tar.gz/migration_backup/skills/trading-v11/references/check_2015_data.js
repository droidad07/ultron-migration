const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const TICKERS = ["NVDA", "AAPL", "GOOGL", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function checkDataAvailability() {
    const ticker = 'AAPL';
    const start = '2015-01-01T04:00:00Z';
    const end = '2015-01-31T04:00:00Z';
    const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
    
    try {
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        console.log(`Bars found for ${ticker} in Jan 2015: ${resp.data.bars ? resp.data.bars.length : 0}`);
        if (resp.data.bars && resp.data.bars.length > 0) {
            console.log(`Sample Bar: ${JSON.stringify(resp.data.bars[0])}`);
        }
    } catch (e) {
        console.error(`Error: ${e.message}`);
    }
}

checkDataAvailability();
