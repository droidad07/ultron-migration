const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const TICKERS = ["NVDA", "AAPL", "GOOGL", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function checkSplitData() {
    const ticker = 'AAPL';
    const dayBefore = '2020-08-28T04:00:00Z';
    const dayOf = '2020-08-31T04:00:00Z';
    
    const urlBefore = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${dayBefore}&end=${dayBefore}`;
    const urlOf = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${dayOf}&end=${dayOf}`;
    
    const respBefore = await axios.get(urlBefore, { headers: ALPACA_HEADERS });
    const respOf = await axios.get(urlOf, { headers: ALPACA_HEADERS });
    
    console.log(`AAPL Aug 28: ${respBefore.data.bars[0].c}`);
    console.log(`AAPL Aug 31: ${respOf.data.bars[0].c}`);
}

checkSplitData();
