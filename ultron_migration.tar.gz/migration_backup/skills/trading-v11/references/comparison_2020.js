const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

function calculateRSI(prices, period = 14) {
    if (prices.length <= period) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
        const diff = prices[prices.length - i] - prices[prices.length - i - 1];
        if (diff >= 0) gains += diff; else losses -= diff;
    }
    const avgGain = gains / period, avgLoss = losses / period;
    return avgLoss === 0 ? 100 : 100 - (100 / (1 + (avgGain / avgLoss)));
}

async function run2020ComparisonBacktest() {
    console.log(`Starting 2020 Stress Test: Compounding vs. Harvesting...`);

    // Fetch data for all of 2020 (and late 2019 for lookback)
    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2019-11-01T00:00:00Z', '2021-01-05T23:59:59Z');
    }

    const tradingDays = allData["AAPL"]
        .filter(b => b.t >= '2020-01-01T00:00:00Z' && b.t <= '2020-12-31T23:59:59Z')
        .map(b => b.t);

    // Two Parallel Portfolios
    let p_comp = { cash: 100.00, holdings: {} }; // Compounding
    let p_harv = { cash: 100.00, holdings: {}, reserve: 0.00 }; // Harvesting

    const comparisonLedger = [];

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        const isMonthEnd = isLastTradingDayOfMonth(dayStr, tradingDays);

        // --- 1. EXIT LOGIC (Same for both) ---
        [p_comp, p_harv].forEach(p => {
            for (const ticker in p.holdings) {
                const dayBar = allData[ticker].find(b => b.t === timestamp);
                if (!dayBar) continue;

                const currentPrice = dayBar.c;
                const history = allData[ticker].filter(b => b.t < timestamp);
                const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
                const stdDev = Math.sqrt(history.slice(-20).reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
                const stopLoss = p.holdings[ticker].costBasis - (1.5 * stdDev);
                const rsi = calculateRSI(history.map(h => h.c));

                if (currentPrice < sma20 || currentPrice < stopLoss || rsi > 75) {
                    const sellQty = p.holdings[ticker].qty;
                    p.cash += sellQty * currentPrice;
                    delete p.holdings[ticker];
                }
            }
        });

        // --- 2. ENTRY LOGIC (Shared Signals) ---
        let signals = [];
        for (const ticker of TICKERS) {
            const history = allData[ticker].filter(b => b.t < timestamp);
            if (history.length < 20) continue;
            const lastClose = history[history.length - 1].c;
            const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
            const rsi = calculateRSI(history.map(h => h.c));

            if ((lastClose > sma20 && rsi < 70) || rsi < 35) signals.push({ ticker, price: lastClose });
        }

        const topSignals = signals.slice(0, 2);
        
        // Deploy Compounding
        if (p_comp.cash > 1.00 && topSignals.length > 0) {
            const spend = p_comp.cash / topSignals.length;
            topSignals.forEach(sig => {
                if (!p_comp.holdings[sig.ticker]) {
                    p_comp.holdings[sig.ticker] = { qty: spend / sig.price, costBasis: sig.price };
                    p_comp.cash -= spend;
                }
            });
        }

        // Deploy Harvesting
        if (p_harv.cash > 1.00 && topSignals.length > 0) {
            const spend = p_harv.cash / topSignals.length;
            topSignals.forEach(sig => {
                if (!p_harv.holdings[sig.ticker]) {
                    p_harv.holdings[sig.ticker] = { qty: spend / sig.price, costBasis: sig.price };
                    p_harv.cash -= spend;
                }
            });
        }

        // --- 3. MONTH END HARVEST (Only for p_harv) ---
        if (isMonthEnd) {
            const monthStartValue = comparisonLedger.length > 0 ? 
                parseFloat(comparisonLedger.filter(l => l.Date.startsWith(dayStr.substring(0, 7))).slice(0,1)[0]?.Harv_Total || 100) : 100;
            
            const currentHarvVal = p_harv.cash + calculateVal(p_harv.holdings, allData, timestamp);
            if (currentHarvVal > monthStartValue) {
                const harvest = (currentHarvVal - monthStartValue) * 0.50;
                // Simplified harvest from cash for the comparison report
                p_harv.reserve += harvest;
                p_harv.cash -= Math.min(p_harv.cash, harvest); 
            }
        }

        const compTotal = p_comp.cash + calculateVal(p_comp.holdings, allData, timestamp);
        const harvActive = p_harv.cash + calculateVal(p_harv.holdings, allData, timestamp);

        comparisonLedger.push({
            Date: dayStr,
            Comp_Total: compTotal.toFixed(2),
            Harv_Active: harvActive.toFixed(2),
            Harv_Reserve: p_harv.reserve.toFixed(2),
            Harv_Ecosystem: (harvActive + p_harv.reserve).toFixed(2),
            Diff_Ecosystem: (compTotal - (harvActive + p_harv.reserve)).toFixed(2)
        });
    }

    const csvHeader = "Date,Comp_Total_Compounding,Harv_Active_Capital,Harv_Reserve_Cash,Harv_Total_Ecosystem,Compounding_Delta";
    const csvRows = comparisonLedger.map(l => `${l.Date},${l.Comp_Total},${l.Harv_Active},${l.Harv_Reserve},${l.Harv_Ecosystem},${l.Diff_Ecosystem}`);
    fs.writeFileSync(path.join(__dirname, 'Ultron_2020_Comparison_Report.csv'), [csvHeader, ...csvRows].join('\n'));
    console.log("2020_COMPARISON_COMPLETE");
}

function calculateVal(holdings, allData, timestamp) {
    let v = 0;
    for (const t in holdings) {
        const bar = allData[t].find(b => b.t === timestamp);
        v += holdings[t].qty * (bar ? bar.c : holdings[t].costBasis);
    }
    return v;
}

function isLastTradingDayOfMonth(dateStr, allDays) {
    const month = dateStr.substring(0, 7);
    const monthDays = allDays.filter(d => d.startsWith(month));
    return monthDays[monthDays.length - 1] === dateStr + 'T00:00:00Z' || monthDays[monthDays.length - 1].startsWith(dateStr);
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

run2020ComparisonBacktest();
