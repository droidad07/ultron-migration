/**
 * Approximate Annual Dividend Yields (Historical 2016-2024 Avg)
 * These are used to estimate "Passive" income during backtests.
 */
const DIVIDEND_DATA = {
    "AAPL": 0.006,  // ~0.6%
    "MSFT": 0.008,  // ~0.8%
    "JPM":  0.025,  // ~2.5%
    "XOM":  0.038,  // ~3.8%
    "GOOGL": 0.00,  // Historically 0 until recently
    "NVDA": 0.001,  // Negligible
    "TSLA": 0.00,
    "AMZN": 0.00,
    "META": 0.00,   // Historically 0 until 2024
    "PSQ":  0.00
};

function calculateDividends(ticker, value, daysHeld) {
    const yield = DIVIDEND_DATA[ticker] || 0;
    if (yield === 0) return 0;
    // Annual yield divided by 252 trading days
    return (value * yield) * (daysHeld / 252);
}

module.exports = { calculateDividends };
