const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const TICKERS = ["NVDA", "AAPL", "GOOGL", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function findEarliestData() {
    const ticker = 'AAPL';
    const dates = ['2016-01-01', '2017-01-01', '2018-01-01'];
    
    for (const d of dates) {
        const start = `${d}T04:00:00Z`;
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&limit=1`;
        try {
            const resp = await axios.get(url, { headers: ALPACA_HEADERS });
            console.log(`Earliest data for ${d}: ${resp.data.bars ? resp.data.bars.length : 0}`);
        } catch (e) {}
    }
}

findEarliestData();
