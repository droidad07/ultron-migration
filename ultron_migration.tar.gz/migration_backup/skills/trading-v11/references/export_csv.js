const fs = require('fs');
const path = require('path');
const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function exportTradesToCSV() {
    console.log("Fetching trades from Supabase...");
    
    const { data, error } = await supabase
        .from('trades')
        .select('timestamp, ticker, side, price, quantity, strategy_name, notes')
        .order('timestamp', { ascending: false });

    if (error) {
        console.error("Error fetching trades:", error.message);
        return;
    }

    if (!data || data.length === 0) {
        console.log("No trades found to export.");
        return;
    }

    const csvRows = [];
    // Header
    const headers = Object.keys(data[0]);
    csvRows.push(headers.join(','));

    // Content
    for (const row of data) {
        const values = headers.map(header => {
            const val = row[header];
            // Escape commas and quotes for CSV safety
            const escaped = ('' + val).replace(/"/g, '""');
            return `"${escaped}"`;
        });
        csvRows.push(values.join(','));
    }

    const fileName = `Ultron_Trade_Report_${new Date().toISOString().split('T')[0]}.csv`;
    const filePath = path.join(__dirname, fileName);
    
    fs.writeFileSync(filePath, csvRows.join('\n'));
    console.log(`FILE_CREATED:${filePath}`);
}

exportTradesToCSV();
