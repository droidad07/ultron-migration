-- Fix quantity to allow decimals for fractional trading
ALTER TABLE trades ALTER COLUMN quantity TYPE DECIMAL;
