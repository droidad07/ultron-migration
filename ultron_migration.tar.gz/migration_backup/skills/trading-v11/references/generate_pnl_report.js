const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function runDetailedPnlReport() {
    const tradingDays = [
        "2024-06-03", "2024-06-04", "2024-06-05", "2024-06-06", "2024-06-07",
        "2024-06-10", "2024-06-11", "2024-06-12", "2024-06-13", "2024-06-14",
        "2024-06-17", "2024-06-18", "2024-06-20", "2024-06-21", "2024-06-24",
        "2024-06-25", "2024-06-26", "2024-06-27", "2024-06-28"
    ];

    let totalPortfolioValue = 100.00; // Starting capital
    const dailyStats = [];

    console.log(`Analyzing Profit/Loss for June 2024...`);

    for (const day of tradingDays) {
        let dailyPnl = 0;
        let daySummary = { day, tickers: [] };

        for (const ticker of TICKERS) {
            const lookbackEnd = new Date(new Date(day).getTime() - (1 * 24 * 60 * 60 * 1000)).toISOString();
            const history = await fetchAlpacaBars(ticker, '2024-04-01T00:00:00Z', lookbackEnd);
            
            if (history.length < 20) continue;

            const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
            const lastClose = history[history.length - 1].c;
            
            // If SMA20 momentum signal is "BUY"
            if (lastClose > sma20) {
                const actualDayData = await fetchAlpacaBars(ticker, day + 'T00:00:00Z', day + 'T23:59:59Z');
                if (actualDayData.length > 0) {
                    const actualClose = actualDayData[actualDayData.length - 1].c;
                    const changePercent = (actualClose - lastClose) / lastClose;
                    
                    // Assume 1/6th of portfolio per ticker for diversification
                    const positionSize = totalPortfolioValue / TICKERS.length;
                    const tradePnl = positionSize * changePercent;
                    
                    dailyPnl += tradePnl;
                    daySummary.tickers.push({ ticker, pnl: tradePnl.toFixed(2), change: (changePercent * 100).toFixed(2) + '%' });
                }
            }
        }

        totalPortfolioValue += dailyPnl;
        dailyStats.push({ 
            day, 
            pnl: dailyPnl.toFixed(2), 
            total: totalPortfolioValue.toFixed(2),
            tickers: daySummary.tickers 
        });

        // Record daily performance to Supabase
        await supabase.from('performance_metrics').insert({
            date: day,
            daily_pnl: dailyPnl,
            logic_version: 'SMA20_v1_Backtest',
            notes: JSON.stringify(daySummary.tickers)
        });
    }

    console.log("FINAL_REPORT_START");
    console.log(JSON.stringify(dailyStats, null, 2));
    console.log("FINAL_REPORT_END");
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runDetailedPnlReport();
