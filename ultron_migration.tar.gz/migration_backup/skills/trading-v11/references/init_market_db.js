const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function initSchema() {
  console.log('Initializing Supabase Schema...');
  
  // Note: We use rpc or just check connection since we can't easily run raw SQL 
  // without a migration tool or the dashboard, but we can verify the connection.
  const { data, error } = await supabase.from('trades').select('*').limit(1);
  
  if (error && error.code === 'PGRST116') {
      console.log('Table "trades" does not exist yet. Please run the SQL schema in your Supabase Dashboard.');
      return false;
  } else if (error) {
      console.error('Connection Error:', error.message);
      return false;
  }
  
  console.log('Connection to Supabase Successful!');
  return true;
}

initSchema();
