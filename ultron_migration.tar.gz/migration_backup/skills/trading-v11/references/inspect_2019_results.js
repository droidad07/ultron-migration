const fs = require('fs');
const path = require('path');
const csv = fs.readFileSync(path.join(__dirname, '..', 'reports', 'Ultron_2019_v12_2_Hybrid.csv'), 'utf8');
const lines = csv.split('\n');
console.log('--- RECENT 2019 TRADES ---');
console.log(lines.slice(-20).join('\n'));
