const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
async function run() {
    const { data, error } = await supabase.rpc('get_schema_details'); // Testing if this RPC exists
    if (error) {
        // Fallback: Check common table names
        const tables = ['trades', 'sentiment_logs', 'logs', 'backtests', 'strategy_configs'];
        for (const t of tables) {
            const { data, error } = await supabase.from(t).select('*').limit(1);
            if (!error) console.log('Table found:', t, 'Columns:', Object.keys(data[0] || {}));
        }
    } else {
        console.log(data);
    }
}
run();
