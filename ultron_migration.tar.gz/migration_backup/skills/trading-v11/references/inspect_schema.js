const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function inspect() {
    // Try to fetch one row from trades and sentiment_logs to see keys
    const { data: trade, error: tErr } = await supabase.from('trades').select('*').limit(1);
    const { data: sentiment, error: sErr } = await supabase.from('sentiment_logs').select('*').limit(1);
    
    console.log('--- TRADES SCHEMA ---');
    if (tErr) console.log('Error:', tErr.message);
    else console.log('Columns:', Object.keys(trade[0] || {}));

    console.log('\n--- SENTIMENT_LOGS SCHEMA ---');
    if (sErr) console.log('Error:', sErr.message);
    else console.log('Columns:', Object.keys(sentiment[0] || {}));

    // Check for any tables that might store learnings/metadata
    const { data: tables, error: pErr } = await supabase.rpc('get_tables'); // Custom RPC check
    if (pErr) console.log('\nRPC get_tables failed (expected if not defined)');
}
inspect();
