const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function migrate() {
    const learningMsg = "v11_2016_ANALYSIS: Strategy showed loss due to high-frequency stop-outs (1.2x StdDev) and regime-switch friction in a sideways market. Scale-up to $1000 amplified slippage impact. Recommendation: Widen stops to 1.5x-2.0x StdDev for choppy years.";
    
    const { data, error } = await supabase
        .from('agent_learnings')
        .insert([
            {
                topic: 'v11_2016_Backtest_Diagnostic',
                content: learningMsg,
                strategy_name: 'v11_precision_lock',
                metadata: {
                    initial_capital: 1000,
                    final_active: 847.03,
                    final_reserve: 29.74,
                    performance: "-12.32%",
                    failure_mode: "sideways_whipsaw",
                    recommendation: "widen_stops_1.5x"
                },
                importance_score: 8
            }
        ]);
        
    if (error) {
        console.error('Migration Error:', error.message);
    } else {
        console.log('Learning successfully migrated to agent_learnings table.');
    }
}
migrate();
