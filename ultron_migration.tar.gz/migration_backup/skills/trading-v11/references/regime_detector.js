const { getMacroSentiment } = require('../references/sentiment_overlay');

/**
 * MARKET REGIME DETECTOR v12.3
 * Added Regime Smoothing to prevent PSQ whipsaws.
 */

let regimeHistory = [];

function detectRegime(prices, sma200, stdDev20) {
    const lastPrice = prices[prices.length - 1];
    const volThreshold = lastPrice * 0.015;
    const isAboveTrend = lastPrice > sma200;
    const isHighVol = stdDev20 > volThreshold;
    const roc5 = (lastPrice - prices[prices.length - 6]) / prices[prices.length - 6];

    let rawRegime;
    if (isAboveTrend && !isHighVol && roc5 > 0) {
        rawRegime = "BULL_TRENDING";
    } else if (isAboveTrend && isHighVol) {
        rawRegime = "CHOPPY_BULL";
    } else if (!isAboveTrend && roc5 < 0) {
        rawRegime = "BEAR_MARKET";
    } else {
        rawRegime = "SIDEWAYS_ACCUMULATION";
    }

    // Regime Smoothing Logic: Require 5 consecutive days to confirm a BEAR switch
    regimeHistory.push(rawRegime);
    if (regimeHistory.length > 5) regimeHistory.shift();

    const bearCount = regimeHistory.filter(r => r === "BEAR_MARKET").length;
    
    // Only return BEAR_MARKET if 4 out of last 5 days were bear
    if (rawRegime === "BEAR_MARKET" && bearCount < 4) {
        return "SIDEWAYS_ACCUMULATION"; // Default to safe sideways during transition
    }

    return rawRegime;
}

module.exports = { detectRegime };
