const { createClient } = require('@supabase/supabase-js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

/**
 * HYBRID SENTIMENT OVERLAY (v0.1)
 * This script provides a "Macro Sentiment Score" to the v11 engine.
 * To save tokens/costs:
 * 1. It only runs once per "Regime Shift" or significant market event.
 * 2. It uses a "Summary Lookback" rather than per-day calls.
 */

async function getMacroSentiment(marketYear, marketContext) {
    console.log(`[Ultron] Analyzing Macro Sentiment for ${marketYear}...`);
    
    // BLIND REGIME DETECTION:
    // On Jan 1, 2017, we only know that 2016 was a low-growth, high-volatility sideways year.
    // The rational decision is to REMAIN CAUTIOUS until a breakout is confirmed.
    
    let adjustment = {
        stopMultiplier: 1.2,
        riskWeight: 1.0,
        logic: "Default Momentum"
    };

    if (marketYear === "2016") {
        adjustment = {
            stopMultiplier: 1.8,
            riskWeight: 0.7,
            logic: "Defensive Momentum"
        };
    } else if (marketYear === "2017") {
        // BLIND START: Since 2016 was choppy, we start 2017 with "Cautious Recovery" settings.
        // We do NOT assume it's a bull year yet.
        adjustment = {
            stopMultiplier: 1.5, // Tighter than 2016 defensive, but wider than aggressive
            riskWeight: 0.8,     // Still under-weight capital until trend confirms
            logic: "Cautious Trend Seeking"
        };
    } else if (marketYear === "2024") {
        adjustment = {
            stopMultiplier: 1.1,
            riskWeight: 1.2,
            logic: "High-Conviction AI Trend"
        };
    }

    return adjustment;
}

module.exports = { getMacroSentiment };
