const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function sync() {
    const learningMsg = "v11_2016_ANALYSIS: Strategy showed loss due to high-frequency stop-outs (1.2x StdDev) and regime-switch friction in a sideways market. Scale-up to $1000 amplified slippage impact. Recommendation: Widen stops to 1.5x-2.0x StdDev for choppy years.";
    
    const { data, error } = await supabase
        .from('trades')
        .insert([
            {
                ticker: 'SYSTEM',
                side: 'LEARNING',
                price: 0,
                quantity: 0,
                strategy_name: 'v11_precision_lock',
                notes: learningMsg,
                timestamp: new Date().toISOString()
            }
        ]);
        
    if (error) {
        console.error('Final Sync Error:', error.message);
    } else {
        console.log('Learning successfully published to Supabase trades table.');
    }
}
sync();
