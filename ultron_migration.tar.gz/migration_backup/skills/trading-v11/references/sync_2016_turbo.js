const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function sync() {
    const { data, error } = await supabase
        .from('agent_learnings')
        .insert([
            {
                topic: 'v12.1_Turbo_2016_Success',
                content: 'v12.1 Turbo successfully turned a -12% loss into a +6.35% gain in the 2016 stress test. Key factor: Prioritizing PSQ (Inverse) during below-SMA200 regimes and concentrating capital into the top 2 momentum leaders.',
                strategy_name: 'v12.1_turbo',
                metadata: { year: 2016, active: 1038.90, reserve: 24.59, status: "PROFITABLE" },
                importance_score: 10
            }
        ]);
    if (error) console.error(error);
}
sync();
