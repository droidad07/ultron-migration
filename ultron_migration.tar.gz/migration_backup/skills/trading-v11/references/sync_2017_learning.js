const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function sync() {
    const { data, error } = await supabase
        .from('agent_learnings')
        .insert([
            {
                topic: 'v11_2017_Blind_Backtest',
                content: '2017 Blind Test: Strategy entered with "Cautious Recovery" settings (1.5x Stop / 0.8 Risk) based on 2016 volatility. While 2017 was a bull year, the strategy underperformed due to excessive caution in the first half. Recommendation: Implement a "Mid-Year Regime Re-assessment" to pivot from cautious to aggressive if trend confirmation is high.',
                strategy_name: 'v11_precision_lock',
                metadata: {
                    year: 2017,
                    active: 862.91,
                    reserve: 25.40,
                    combined: 888.31,
                    adjustment: "cautious_blind_start"
                },
                importance_score: 7
            }
        ]);
    if (error) console.error(error);
    else console.log('2017 learning synced.');
}
sync();
