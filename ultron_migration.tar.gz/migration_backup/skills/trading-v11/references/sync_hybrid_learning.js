const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function sync() {
    const { data, error } = await supabase
        .from('agent_learnings')
        .insert([
            {
                topic: 'v11_Hybrid_Overlay_Test',
                content: 'First test of Hybrid Sentiment Overlay. By widening stops to 1.8x and reducing risk to 0.7 (AI-informed parameters), the 2016 loss was mitigated by ~$50. The strategy is still negative due to the 2016 regime, but the "whipsaw" effect was significantly reduced.',
                strategy_name: 'v11_precision_lock',
                metadata: {
                    year: 2016,
                    old_active: 847.03,
                    new_active: 894.71,
                    improvement: "+47.68",
                    overlay_type: "one-shot_macro"
                },
                importance_score: 9
            }
        ]);
    if (error) console.error(error);
    else console.log('Hybrid learning synced.');
}
sync();
