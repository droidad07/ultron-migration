const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function syncJuneToSupabase() {
    // Porting the exact logic from the corrected June run to Supabase
    let cash = 0.00; 
    let holdings = {}; 
    let currentPortfolioValue = 152.63;
    const initialSplit = currentPortfolioValue / 2;

    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2024-04-01T00:00:00Z', '2024-07-01T23:59:59Z');
    }

    const firstDay = '2024-06-03T04:00:00Z';
    const nvdaMayClose = allData["NVDA"].filter(b => b.t < firstDay).slice(-1)[0].c;
    const aaplMayClose = allData["AAPL"].filter(b => b.t < firstDay).slice(-1)[0].c;

    holdings["NVDA"] = { qty: initialSplit / nvdaMayClose, costBasis: nvdaMayClose };
    holdings["AAPL"] = { qty: initialSplit / aaplMayClose, costBasis: aaplMayClose };

    // Log Initial Holdings to Supabase
    await logToSupabase("2024-06-03", "NVDA", "INITIAL_HOLDING", nvdaMayClose, holdings["NVDA"].qty, initialSplit, 0, 0, currentPortfolioValue, "Carried from May");
    await logToSupabase("2024-06-03", "AAPL", "INITIAL_HOLDING", aaplMayClose, holdings["AAPL"].qty, initialSplit, 0, 0, currentPortfolioValue, "Carried from May");

    const tradingDays = allData["NVDA"]
        .filter(b => b.t >= '2024-06-01T00:00:00Z' && b.t <= '2024-06-30T23:59:59Z')
        .map(b => b.t);

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;

            const currentPrice = dayBar.c;
            const history = allData[ticker].filter(b => b.t < timestamp);
            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const stdDev = Math.sqrt(window.reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
            const stopLoss = holdings[ticker].costBasis - (1.5 * stdDev);

            let isSplit = (ticker === 'NVDA' && dayStr === '2024-06-10');

            if ((currentPrice < sma20 || currentPrice < stopLoss) && !isSplit) {
                const sellQty = holdings[ticker].qty;
                const proceeds = sellQty * currentPrice;
                const pnl = proceeds - (sellQty * holdings[ticker].costBasis);
                cash += proceeds;
                
                await logToSupabase(dayStr, ticker, "SELL", currentPrice, sellQty, proceeds, pnl, cash, calculateHoldingsValue(holdings, allData, timestamp, ticker), currentPrice < stopLoss ? "STOP_HIT" : "MOMENTUM_LOSS");
                delete holdings[ticker];
            } else if (isSplit) {
                holdings[ticker].qty *= 10;
                holdings[ticker].costBasis /= 10;
                await logToSupabase(dayStr, ticker, "SPLIT_ADJUST", currentPrice, holdings[ticker].qty, 0, 0, cash, calculateHoldingsValue(holdings, allData, timestamp), "10-for-1 Stock Split");
            }
        }

        if (cash > 1.00) {
            let activeSignals = [];
            for (const ticker of TICKERS) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 20) continue;
                const window = history.slice(-20);
                const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
                const lastClose = history[history.length - 1].c;
                if (lastClose > sma20) activeSignals.push({ ticker, price: lastClose });
            }

            const signalsToBuy = activeSignals.slice(0, 2);
            const maxSpend = cash / Math.max(1, signalsToBuy.length);

            for (const sig of signalsToBuy) {
                const spend = Math.min(cash, maxSpend);
                const qty = spend / sig.price;
                cash -= spend;
                holdings[sig.ticker] = { qty, costBasis: sig.price };
                await logToSupabase(dayStr, sig.ticker, "BUY", sig.price, qty, spend, 0, cash, calculateHoldingsValue(holdings, allData, timestamp), "SMA20_RE-ENTRY");
            }
        }
    }
    console.log("SYNC_COMPLETE");
}

async function logToSupabase(date, ticker, side, price, qty, amount, pnl, cash, invested, reason) {
    const { error } = await supabase.from('trades').insert({
        timestamp: new Date(date).toISOString(),
        ticker: ticker,
        side: side,
        price: price,
        quantity: qty,
        strategy_name: 'TrueLedger_v5',
        notes: JSON.stringify({
            amount,
            pnl,
            cash_on_hand: cash,
            invested_value: invested,
            reason
        })
    });
    if (error) console.error('Supabase Error:', error.message);
}

function calculateHoldingsValue(holdings, allData, timestamp, excludeTicker = null) {
    let value = 0;
    for (const ticker in holdings) {
        if (ticker === excludeTicker) continue;
        const dayBar = allData[ticker].find(b => b.t === timestamp);
        if (dayBar) value += holdings[ticker].qty * dayBar.c;
        else value += holdings[ticker].qty * holdings[ticker].costBasis;
    }
    return value;
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

syncJuneToSupabase();
