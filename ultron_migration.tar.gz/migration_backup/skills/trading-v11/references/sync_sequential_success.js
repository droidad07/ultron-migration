const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function sync() {
    const { data, error } = await supabase
        .from('agent_learnings')
        .insert([
            {
                topic: 'v12.1_Sequential_Success_2016-2017',
                content: 'Sequential backtest successful. v12.1 Turbo grew the ecosystem from $1000 to $1196.88 over 2 years (2016-2017). Active capital carryover provided the necessary base for 2017 compounding.',
                strategy_name: 'v12.1_turbo',
                metadata: { total_value: 1196.88, total_reserve: 51.58, active_carryover: 1145.30, years: [2016, 2017] },
                importance_score: 10
            }
        ]);
    if (error) console.error(error);
}
sync();
