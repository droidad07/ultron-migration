const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function sync() {
    const { data, error } = await supabase
        .from('trades')
        .insert([
            {
                ticker: 'SYSTEM_DIAGNOSTIC',
                action: 'LEARNING',
                price: 0,
                qty: 0,
                reason: 'v11_2016_LOSS_ANALYSIS: Sideways market triggered high stop-out frequency (1.2x StdDev). Scale-up to $1000 increased friction compared to $100 test.'
            }
        ]);
    if (error) console.error(error);
    else console.log('Learning synced to trades table.');
}
sync();
