const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

async function sync() {
    const { data, error } = await supabase
        .from('agent_learnings')
        .insert([
            {
                topic: 'v12_Dynamic_Conviction_Test',
                content: 'v12 Test: Implemented Regime Detector. While 2017 showed slight improvement, the strategy is still fighting friction. Key Discovery: The Hard Floor (7%) and Regime-based Harvesting (Reduced to 5% in Bull) preserved more capital, but the entry timing needs a stronger volume or volatility-contraction filter to avoid fake-outs.',
                strategy_name: 'v12_dynamic_conviction',
                metadata: {
                    year: 2017,
                    active: 868.84,
                    reserve: 34.49,
                    improvement_vs_v11: "+6.00"
                },
                importance_score: 8
            }
        ]);
    if (error) console.error(error);
    else console.log('v12 learning synced.');
}
sync();
