require('dotenv').config();
const axios = require('axios');

async function testAlpaca() {
  console.log('Verifying Alpaca Connection...');
  try {
    const response = await axios.get('https://paper-api.alpaca.markets/v2/account', {
      headers: {
        'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
        'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
      }
    });
    console.log('Alpaca Account Verified! Status:', response.data.status);
    console.log('Buying Power:', response.data.buying_power);
  } catch (error) {
    console.error('Alpaca Error:', error.response ? error.response.data : error.message);
  }
}

testAlpaca();
