const axios = require('axios');
require('dotenv').config();

const ALPACA_BASE_URL = 'https://paper-api.alpaca.markets';
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function liquidateAll() {
    console.log("🧹 ULTRON: Initiating Clean Sweep...");
    try {
        const posResp = await axios.get(`${ALPACA_BASE_URL}/v2/positions`, { headers: ALPACA_HEADERS });
        const positions = posResp.data;

        for (const pos of positions) {
            console.log(`Selling ${pos.symbol} (${pos.qty} shares)...`);
            await axios.delete(`${ALPACA_BASE_URL}/v2/orders?symbol=${pos.symbol}`, { headers: ALPACA_HEADERS }); // Cancel open orders
            await axios.post(`${ALPACA_BASE_URL}/v2/orders`, {
                symbol: pos.symbol,
                qty: pos.qty,
                side: 'sell',
                type: 'market',
                time_in_force: 'day'
            }, { headers: ALPACA_HEADERS });
            console.log(`✅ ${pos.symbol} liquidated.`);
        }
        console.log("✨ All positions closed. Budget reset to cash.");
    } catch (err) {
        console.error("❌ Liquidation failed:", err.response?.data || err.message);
    }
}

liquidateAll();
