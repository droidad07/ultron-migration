const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
require('dotenv').config();

const { detectRegime } = require('../references/regime_detector');
const { calculateDividends } = require('../references/dividend_yields');

/**
 * ULTRON V12.5 APEX - LIVE PILOT ENGINE (Paper Trading)
 * ----------------------------------------------------
 * Scheduled Cycle:
 * 1. Morning Execution (09:45 AM EST) - Main Buy/Sell
 * 2. Mid-Day Shield (12:45 PM EST) - Stop-Loss Check & Catch-up Buy
 * 3. Power Hour (03:45 PM EST) - Final Trend/Harvest
 */

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META", "PSQ"];
const BENCH_TICKERS = ["AMD", "AVGO", "SMCI", "MS", "GS", "CVX", "COP", "UNH", "LLY", "V", "MA", "COST", "WMT", "BRK.B"];
const PILOT_BUDGET = 1000.00; 
const ALPACA_BASE_URL = 'https://paper-api.alpaca.markets';
const ALPACA_DATA_URL = 'https://data.alpaca.markets/v2';
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function executeLiveCycle(phaseName) {
    console.log(`\n🤖 [${new Date().toISOString()}] ULTRON LIVE PILOT: Starting Phase - ${phaseName}`);

    try {
        // 1. Get Account Info
        const account = await axios.get(`${ALPACA_BASE_URL}/v2/account`, { headers: ALPACA_HEADERS });
        const cash = parseFloat(account.data.cash);
        const portfolioValue = parseFloat(account.data.portfolio_value);
        console.log(`Balance: $${cash.toFixed(2)} | Portfolio: $${portfolioValue.toFixed(2)}`);

        // 2. Fetch Current Positions
        const posResp = await axios.get(`${ALPACA_BASE_URL}/v2/positions`, { headers: ALPACA_HEADERS });
        const positions = posResp.data;

        const currentExposure = positions.reduce((acc, p) => acc + parseFloat(p.market_value), 0);
        const availablePilotCash = Math.max(0, PILOT_BUDGET - currentExposure);
        console.log(`Pilot Budget: $${PILOT_BUDGET.toFixed(2)} | Current Exposure: $${currentExposure.toFixed(2)} | Available: $${availablePilotCash.toFixed(2)}`);

        // 3. Regime Detection
        const marketBars = await fetchBars("MSFT", 250);
        if (!marketBars || marketBars.length < 50) {
            console.log("⚠️ Skipping Cycle: Insufficient market anchor (MSFT) data.");
            return;
        }

        const latestPrice = marketBars[marketBars.length - 1].c;
        const prices20 = marketBars.slice(-20).map(b => b.c);
        const avg20 = prices20.reduce((a, b) => a + b, 0) / 20;
        const stdDev20 = Math.sqrt(prices20.reduce((a, b) => a + Math.pow(b - avg20, 2), 0) / 20);
        
        const sma200 = marketBars.length >= 200 
            ? (marketBars.slice(-200).reduce((acc, val) => acc + val.c, 0) / 200)
            : latestPrice;

        const regime = detectRegime(prices20, sma200, stdDev20);
        console.log(`Market Regime: ${regime}`);

        // 4. SHIELD LOGIC
        for (const pos of positions) {
            const ticker = pos.symbol;
            if (!TICKERS.includes(ticker) && !BENCH_TICKERS.includes(ticker)) continue;

            const currentPrice = parseFloat(pos.current_price);
            const entryPrice = parseFloat(pos.avg_entry_price);
            
            const stopMult = (regime === "BEAR_MARKET") ? 2.5 : 1.8;
            const hardFloor = entryPrice * 0.93; 
            const trailingStop = currentPrice - (stopMult * stdDev20);

            if (currentPrice < Math.max(trailingStop, hardFloor)) {
                console.log(`🚨 SHIELD TRIGGERED: Selling ${ticker} at ${currentPrice}`);
                await placeOrder(ticker, pos.qty, 'sell');
                await logTrade(ticker, 'SELL', currentPrice, pos.qty, 'STOP_SHIELD_TRIGGER');
            }
        }

        // 5. ENTRY LOGIC
        const isEntryPhase = phaseName === "MORNING_EXECUTION" || (phaseName === "MIDDAY_SHIELD" && currentExposure === 0);
        
        if (isEntryPhase && availablePilotCash > 50) {
            console.log(`🔍 Scanning Universe for Apex Signals...`);
            let signals = [];
            
            const scanList = async (list, label) => {
                console.log(`   -- Scanning ${label} --`);
                for (const ticker of list) {
                    if (positions.find(p => p.symbol === ticker)) continue;
                    
                    const bars = await fetchBars(ticker, 50);
                    if (!bars || bars.length < 21) continue; 

                    const lastClose = bars[bars.length - 1].c;
                    const windowSize = Math.min(20, bars.length);
                    const sma20 = bars.slice(-windowSize).reduce((acc, val) => acc + (val.c || 0), 0) / windowSize;
                    const rsi = calculateRSI(bars.map(b => b.c || 0));
                    
                    const refIdx = Math.max(0, bars.length - 21);
                    const roc20 = (lastClose - bars[refIdx].c) / bars[refIdx].c;

                    console.log(`      [${ticker}] Price: ${lastClose.toFixed(2)} | SMA20: ${sma20.toFixed(2)} | RSI: ${rsi.toFixed(1)} | ROC20: ${(roc20 * 100).toFixed(2)}%`);

                    const rocThreshold = (regime === "BULL_TRENDING") ? 0.03 : 0.05;
                    if (lastClose > sma20 && rsi < 70) {
                        if (roc20 > rocThreshold) {
                            signals.push({ ticker, price: lastClose, roc: roc20, source: label });
                        }
                    }
                }
            };

            await scanList(TICKERS, "Primary");
            
            if (signals.length === 0) {
                await scanList(BENCH_TICKERS, "Bench");
            }

            signals.sort((a, b) => b.roc - a.roc);
            // Limit to top 3 signals to diversify slightly and use more budget
            const topSignals = signals.slice(0, 3);
            
            if (topSignals.length > 0) {
                const riskWeight = (regime === "BULL_TRENDING") ? 0.95 : 0.85; // Increased weight to utilize more budget
                const totalSpend = availablePilotCash * riskWeight;
                const spendPerTicker = totalSpend / topSignals.length;

                for (const best of topSignals) {
                    if (spendPerTicker < 1.00) continue; // Alpaca minimum for fractional

                    console.log(`🎯 SNIPER ENTRY: Buying ${best.ticker} (${best.source}) | Target Spend: $${spendPerTicker.toFixed(2)}`);
                    try {
                        await placeOrder(best.ticker, spendPerTicker, 'buy', true);
                        const shares = (spendPerTicker / best.price).toFixed(6);
                        await logTrade(best.ticker, 'BUY', best.price, shares, `Apex_${best.source}_Budget_${regime}_FRACTIONAL`);
                    } catch (err) {
                        console.error(`❌ Order Failed for ${best.ticker}: ${err.response?.data?.message || err.message}`);
                    }
                }
            } else {
                console.log("ℹ️  No valid Alpha signals found in this scan.");
            }
        }
    } catch (err) {
        console.error(`❌ CRITICAL ERROR in Pilot: ${err.message}`);
    }
}

async function fetchBars(ticker, limit) {
    try {
        const end = new Date(Date.now() - 16 * 60 * 1000).toISOString();
        const start = new Date(Date.now() - 100 * 24 * 60 * 60 * 1000).toISOString(); 
        const url = `${ALPACA_DATA_URL}/stocks/${ticker}/bars?timeframe=1Day&limit=${limit}&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (err) {
        console.error(`⚠️ Data Fetch Error [${ticker}]: ${err.message}`);
        return [];
    }
}

async function placeOrder(symbol, amount, side, isFractional = false) {
    const orderData = {
        symbol,
        side,
        type: 'market',
        time_in_force: 'day'
    };

    if (isFractional && side === 'buy') {
        orderData.notional = amount.toFixed(2);
    } else {
        orderData.qty = amount;
    }

    return axios.post(`${ALPACA_BASE_URL}/v2/orders`, orderData, { headers: ALPACA_HEADERS });
}

async function logTrade(ticker, side, price, quantity, reason) {
    try {
        await supabase.from('trades').insert([{
            ticker, side, price, quantity, strategy_name: 'v12.5_Apex_Pilot', notes: reason, timestamp: new Date().toISOString()
        }]);
    } catch (err) {
        console.error(`Supabase Log Error: ${err.message}`);
    }
}

function calculateRSI(prices, period = 14) {
    if (prices.length <= period) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
        const diff = prices[prices.length - i] - prices[prices.length - i - 1];
        if (diff >= 0) gains += diff; else losses -= diff;
    }
    const avgGain = (gains / period);
    const avgLoss = (losses / period);
    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
}

if (require.main === module) {
    const phase = process.argv[2] || "MORNING_EXECUTION";
    executeLiveCycle(phase);
}

module.exports = { executeLiveCycle };
