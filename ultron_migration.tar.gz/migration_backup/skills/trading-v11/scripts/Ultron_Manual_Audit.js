const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
require('dotenv').config();

const ALPACA_BASE_URL = 'https://paper-api.alpaca.markets';
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function audit() {
    console.log("--- ULTRON PORTFOLIO AUDIT ---");
    try {
        const posResp = await axios.get(`${ALPACA_BASE_URL}/v2/positions`, { headers: ALPACA_HEADERS });
        const positions = posResp.data;
        if (positions.length === 0) {
            console.log("No open positions.");
        } else {
            console.log(`Found ${positions.length} open positions:`);
            positions.forEach(p => {
                console.log(`- ${p.symbol}: ${p.qty} shares | Value: $${p.market_value} | G/L: $${p.unrealized_pl}`);
            });
        }
        
        const ordersResp = await axios.get(`${ALPACA_BASE_URL}/v2/orders?status=open`, { headers: ALPACA_HEADERS });
        console.log(`Open Orders: ${ordersResp.data.length}`);
    } catch (err) {
        console.error("Audit failed:", err.message);
    }
}

audit();
