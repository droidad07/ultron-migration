const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const { detectRegime } = require('../references/regime_detector');
const { calculateDividends } = require('../references/dividend_yields');

/**
 * ULTRON V12.5 APEX - UNIFIED MASTER ENGINE
 * ----------------------------------------
 * Features:
 * - Dynamic Regime Detection & Smoothing
 * - Sector Rotation (Sniper Rule)
 * - 7% Hard Shield / Trailing Stop Hybrid
 * - Dividend Accrual & Reinvestment
 * - Automated 5% Safety Harvest
 * - Split Handling (NVDA/TSLA)
 */

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META", "PSQ"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function runUltronApex(config) {
    const { start, end, initialCash, initialReserve } = config;
    console.log(`\n🤖 ULTRON V12.5 APEX: Initializing...`);
    console.log(`Range: ${start} to ${end} | Initial: $${initialCash}`);

    const allData = {};
    for (const ticker of TICKERS) {
        // Lookback buffer of 250 days for SMA200
        const lookbackDate = new Date(new Date(start).getTime() - (365 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0];
        allData[ticker] = await fetchAlpacaBars(ticker, lookbackDate, end);
    }

    const firstTicker = "AAPL";
    const tradingDays = allData[firstTicker]
        .filter(b => b.t >= start && b.t <= end)
        .map(b => b.t);

    if (tradingDays.length === 0) {
        console.error("❌ No trading data found for this range.");
        return;
    }

    let cash = parseFloat(initialCash); 
    let holdings = {}; 
    let reserve = parseFloat(initialReserve); 
    let monthStartValue = cash;
    let totalDividends = 0;
    const ledger = [];
    const SLIPPAGE = 0.0005;

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        const isMonthEnd = isLastTradingDayOfMonth(dayStr, tradingDays);

        // --- BRAIN: REGIME DETECTION ---
        const marketHistory = allData["MSFT"].filter(b => b.t < timestamp);
        if (marketHistory.length < 200) continue; 

        const sma200 = marketHistory.slice(-200).reduce((acc, val) => acc + val.c, 0) / 200;
        const prices20 = marketHistory.slice(-20).map(b => b.c);
        const avg20 = prices20.reduce((a,b) => a+b, 0) / 20;
        const stdDev20 = Math.sqrt(prices20.reduce((a,b) => a + Math.pow(b - avg20, 2), 0) / 20);
        
        const regime = detectRegime(prices20, sma200, stdDev20);

        let stopMult = (regime === "BULL_TRENDING") ? 1.5 : 2.5;
        let riskWeight = (regime === "BULL_TRENDING") ? 1.5 : 0.6; 
        let harvestRate = 0.05;

        // 1. EXIT LOGIC & MAINTENANCE
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;
            const currentPrice = dayBar.c;

            // Split Logic (NVDA 2024, TSLA 2022/2020)
            handleSplits(ticker, dayStr, holdings[ticker]);

            const div = calculateDividends(ticker, holdings[ticker].qty * currentPrice, 1);
            totalDividends += div;
            cash += div;

            const history = allData[ticker].filter(b => b.t < timestamp);
            const rsi = calculateRSI(history.map(h => h.c));
            const hardFloor = holdings[ticker].costBasis * 0.93; 
            const trailingStop = currentPrice - (stopMult * stdDev20);
            if (trailingStop > holdings[ticker].trailingStop) holdings[ticker].trailingStop = trailingStop;

            if (currentPrice < Math.max(holdings[ticker].trailingStop, hardFloor) || rsi > 85) {
                const sellQty = holdings[ticker].qty;
                const proceeds = (sellQty * currentPrice) * (1 - SLIPPAGE);
                cash += proceeds;
                ledger.push({
                    Date: dayStr, Ticker: ticker, Action: "SELL", Price: currentPrice.toFixed(2),
                    Qty: sellQty.toFixed(6), Amount: proceeds.toFixed(2), PnL: (proceeds - (sellQty * holdings[ticker].costBasis)).toFixed(2),
                    Reason: rsi > 85 ? "RSI_LIMIT" : "STOP_OUT", Regime: regime
                });
                delete holdings[ticker];
            } else {
                holdings[ticker].lastPrice = currentPrice;
            }
        }

        // 2. ENTRY LOGIC (Sniper Focus)
        if (cash > 20.00) {
            let signals = [];
            for (const ticker of TICKERS) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 50) continue;
                const lastClose = history[history.length - 1].c;
                const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
                const rsi = calculateRSI(history.map(h => h.c));
                
                if (ticker === "PSQ" && regime === "BEAR_MARKET") {
                    signals.push({ ticker, price: lastClose, roc: 999 });
                } else if (lastClose > sma20 && rsi < 65) {
                    const roc20 = (lastClose - history[history.length - 21].c) / history[history.length - 21].c;
                    if (roc20 > 0.05) signals.push({ ticker, price: lastClose, roc: roc20 });
                }
            }
            
            signals.sort((a, b) => b.roc - a.roc);
            const signalsToBuy = signals.slice(0, 1);
            
            for (const sig of signalsToBuy) {
                const spend = cash * riskWeight;
                if (spend < 50) continue;
                holdings[sig.ticker] = { qty: spend / sig.price, costBasis: sig.price, trailingStop: sig.price * 0.88, lastPrice: sig.price };
                cash -= spend * (1 + SLIPPAGE);
                ledger.push({
                    Date: dayStr, Ticker: sig.ticker, Action: "BUY", Price: sig.price.toFixed(2),
                    Qty: holdings[sig.ticker].qty.toFixed(6), Amount: spend.toFixed(2),
                    Reason: `Apex_${regime}`
                });
            }
        }

        if (isMonthEnd) {
            const currentTotalVal = cash + calculateVal(holdings, allData, timestamp);
            if (currentTotalVal > monthStartValue) {
                const harvestAmount = (currentTotalVal - monthStartValue) * harvestRate;
                reserve += harvestAmount;
                cash -= Math.min(cash, harvestAmount);
            }
            monthStartValue = cash + calculateVal(holdings, allData, timestamp);
        }
    }

    const finalActive = cash + calculateVal(holdings, allData, tradingDays[tradingDays.length-1]);
    const reportPath = path.join(__dirname, '..', 'reports', `Ultron_Master_Report_${new Date().getTime()}.csv`);
    saveCSV(reportPath, ledger);

    console.log(`\n🏆 RUN COMPLETE`);
    console.log(`Active Portfolio: $${finalActive.toFixed(2)}`);
    console.log(`Total Reserve:    $${reserve.toFixed(2)}`);
    console.log(`Dividends Accrued: $${totalDividends.toFixed(2)}`);
    console.log(`Report: ${reportPath}`);
    
    return { finalActive, reserve, reportPath };
}

// --- UTILITIES ---

function handleSplits(ticker, date, holding) {
    const splits = {
        'NVDA': { '2024-06-10': 10, '2021-07-20': 4 },
        'TSLA': { '2022-08-25': 3, '2020-08-31': 5 },
        'AAPL': { '2020-08-31': 4 }
    };
    if (splits[ticker] && splits[ticker][date] && !holding[`split_${date}`]) {
        const ratio = splits[ticker][date];
        holding.qty *= ratio;
        holding.costBasis /= ratio;
        holding.trailingStop /= ratio;
        holding[`split_${date}`] = true;
        console.log(`[SPLIT] ${ticker} adjusted ${ratio}:1 on ${date}`);
    }
}

function calculateVal(holdings, allData, timestamp) {
    let v = 0;
    for (const t in holdings) {
        const bar = allData[t].find(b => b.t === timestamp);
        v += holdings[t].qty * (bar ? bar.c : holdings[t].lastPrice);
    }
    return v;
}

function isLastTradingDayOfMonth(dateStr, allDays) {
    const month = dateStr.substring(0, 7);
    const monthDays = allDays.filter(d => d.startsWith(month));
    return monthDays[monthDays.length - 1].startsWith(dateStr);
}

function calculateRSI(prices, period = 14) {
    if (prices.length <= period) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
        const diff = prices[prices.length - i] - prices[prices.length - i - 1];
        if (diff >= 0) gains += diff; else losses -= diff;
    }
    return 100 - (100 / (1 + ((gains/period) / (losses/period))));
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}T00:00:00Z&end=${end}T23:59:59Z`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

function saveCSV(filePath, ledger) {
    if (!fs.existsSync(path.dirname(filePath))) fs.mkdirSync(path.dirname(filePath));
    const header = Object.keys(ledger[0]).join(',');
    const rows = ledger.map(l => Object.values(l).join(','));
    fs.writeFileSync(filePath, [header, ...rows].join('\n'));
}

// EXECUTION (Example: Full Sequence)
if (require.main === module) {
    runUltronApex({
        start: '2016-01-01',
        end: '2024-12-31',
        initialCash: 1000,
        initialReserve: 0
    });
}

module.exports = { runUltronApex };
