const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

function calculateRSI(prices, period = 14) {
    if (prices.length <= period) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
        const diff = prices[prices.length - i] - prices[prices.length - i - 1];
        if (diff >= 0) gains += diff; else losses -= diff;
    }
    const avgGain = gains / period, avgLoss = losses / period;
    return avgLoss === 0 ? 100 : 100 - (100 / (1 + (avgGain / avgLoss)));
}

async function runAugustV7() {
    let cash = 164.49; // From July close
    let holdings = {}; 
    const ledger = [];

    console.log(`Starting August 2024 "True Ledger" with v7 (Dual-Signal: Momentum + Mean Reversion)...`);

    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2024-06-01T00:00:00Z', '2024-09-01T23:59:59Z');
    }

    const tradingDays = allData["NVDA"]
        .filter(b => b.t >= '2024-08-01T00:00:00Z' && b.t <= '2024-08-31T23:59:59Z')
        .map(b => b.t);

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        
        // 1. EXIT LOGIC (Standard + Profit Taking)
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;

            const currentPrice = dayBar.c;
            const history = allData[ticker].filter(b => b.t < timestamp);
            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const stdDev = Math.sqrt(window.reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
            const stopLoss = holdings[ticker].costBasis - (1.5 * stdDev);
            
            const rsi = calculateRSI(history.map(h => h.c));

            // EXIT: Price < SMA20 OR Stop Loss OR Overbought (RSI > 75)
            if (currentPrice < sma20 || currentPrice < stopLoss || rsi > 75) {
                const sellQty = holdings[ticker].qty;
                const proceeds = sellQty * currentPrice;
                const pnl = proceeds - (sellQty * holdings[ticker].costBasis);
                cash += proceeds;
                
                let reason = "MOMENTUM_LOSS";
                if (currentPrice < stopLoss) reason = "STOP_HIT";
                if (rsi > 75) reason = "PROFIT_TAKE_RSI";

                await logToSupabase(dayStr, ticker, "SELL", currentPrice, sellQty, proceeds, pnl, cash, calculateHoldingsValue(holdings, allData, timestamp, ticker), reason);
                delete holdings[ticker];
            }
        }

        // 2. DUAL-ENTRY LOGIC
        if (cash > 1.00) {
            let activeSignals = [];
            for (const ticker of TICKERS) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 20) continue;
                const window = history.slice(-20);
                const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
                const lastClose = history[history.length - 1].c;
                const rsi = calculateRSI(history.map(h => h.c));

                // Signal A: Momentum (SMA20 + RSI < 70)
                // Signal B: Mean Reversion (RSI < 35 - "Buy the Dip")
                if ((lastClose > sma20 && rsi < 70) || (rsi < 35)) {
                    activeSignals.push({ ticker, price: lastClose, rsi, type: rsi < 35 ? "DIP" : "MOMENTUM" });
                }
            }

            const signalsToBuy = activeSignals.slice(0, 3); // Max 3 concentrated positions
            const maxSpend = cash / Math.max(1, signalsToBuy.length);

            for (const sig of signalsToBuy) {
                const spend = Math.min(cash, maxSpend);
                const qty = spend / sig.price;
                cash -= spend;
                holdings[sig.ticker] = { qty, costBasis: sig.price };
                await logToSupabase(dayStr, sig.ticker, "BUY", sig.price, qty, spend, 0, cash, calculateHoldingsValue(holdings, allData, timestamp), `v7_${sig.type}_RSI(${sig.rsi.toFixed(1)})`);
            }
        }
    }
    const finalValue = cash + calculateHoldingsValue(holdings, allData, tradingDays[tradingDays.length-1]);
    console.log(`FINAL_BALANCE:${finalValue.toFixed(2)}`);
}

async function logToSupabase(date, ticker, side, price, qty, amount, pnl, cash, invested, reason) {
    await supabase.from('trades').insert({
        timestamp: new Date(date).toISOString(),
        ticker: ticker,
        side: side,
        price: price,
        quantity: qty,
        strategy_name: 'v7_DualSignal',
        notes: JSON.stringify({ amount, pnl, cash_on_hand: cash, invested_value: invested, reason })
    });
}

function calculateHoldingsValue(holdings, allData, timestamp, excludeTicker = null) {
    let value = 0;
    for (const ticker in holdings) {
        if (ticker === excludeTicker) continue;
        const dayBar = allData[ticker].find(b => b.t === timestamp);
        if (dayBar) value += holdings[ticker].qty * dayBar.c;
        else value += holdings[ticker].qty * holdings[ticker].costBasis;
    }
    return value;
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runAugustV7();
