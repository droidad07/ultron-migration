const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META", "PSQ"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

function calculateRSI(prices, period = 14) {
    if (prices.length <= period) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
        const diff = prices[prices.length - i] - prices[prices.length - i - 1];
        if (diff >= 0) gains += diff; else losses -= diff;
    }
    const avgGain = gains / period, avgLoss = losses / period;
    return avgLoss === 0 ? 100 : 100 - (100 / (1 + (avgGain / avgLoss)));
}

const { getMacroSentiment } = require('../references/sentiment_overlay');

async function run2016V11Simulation() {
    console.log(`Starting 2016 Era Simulation: v11 Precision Lock ($1000 Initial)...`);
    
    // ONE-SHOT AI OVERLAY CALL (Saves Tokens)
    const sentiment = await getMacroSentiment("2016", "Sideways market, high volatility");
    console.log(`[ULTRON OVERLAY] Stop Multiplier: ${sentiment.stopMultiplier}x | Risk Weight: ${sentiment.riskWeight}`);

    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2015-06-01T00:00:00Z', '2017-01-05T23:59:59Z');
    }

    const firstTicker = "AAPL";
    if (!allData[firstTicker] || allData[firstTicker].length === 0) {
        console.error("No data found for 2016.");
        return;
    }

    const tradingDays = allData[firstTicker]
        .filter(b => b.t >= '2016-01-01T00:00:00Z' && b.t <= '2016-12-31T23:59:59Z')
        .map(b => b.t);

    let cash = 1000.00; 
    let holdings = {}; 
    let reserve = 0.00; 
    let monthStartValue = 1000.00;
    const ledger = [];
    const SLIPPAGE = 0.0005;

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        const isMonthEnd = isLastTradingDayOfMonth(dayStr, tradingDays);

        const marketHistory = allData["MSFT"].filter(b => b.t < timestamp);
        if (marketHistory.length < 200) {
            // Not enough data for SMA200 yet on early 2016 days, assume not in danger
            var isDangerRegime = false;
        } else {
            const sma200 = marketHistory.slice(-200).reduce((acc, val) => acc + val.c, 0) / 200;
            const lastMarketPrice = marketHistory[marketHistory.length - 1].c;
            var isDangerRegime = lastMarketPrice < sma200;
        }

        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;
            const currentPrice = dayBar.c;
            const prevPrice = holdings[ticker].lastPrice;

            const change = (currentPrice - prevPrice) / prevPrice;
            if (Math.abs(change) > 0.40) {
                const ratio = Math.round(prevPrice / currentPrice);
                if (ratio > 1) {
                    holdings[ticker].qty *= ratio;
                    holdings[ticker].costBasis /= ratio;
                    holdings[ticker].trailingStop /= ratio;
                }
            }

            const history = allData[ticker].filter(b => b.t < timestamp);
            const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
            const rsi = calculateRSI(history.map(h => h.c));
            const stdDev = Math.sqrt(history.slice(-20).reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
            
            const potentialStop = currentPrice - (sentiment.stopMultiplier * stdDev);
            if (potentialStop > holdings[ticker].trailingStop) holdings[ticker].trailingStop = potentialStop;

            if (currentPrice < sma20 || currentPrice < holdings[ticker].trailingStop || rsi > 75) {
                const sellQty = holdings[ticker].qty;
                const proceeds = (sellQty * currentPrice) * (1 - SLIPPAGE);
                cash += proceeds;
                ledger.push({
                    Date: dayStr, Ticker: ticker, Action: "SELL", Price: currentPrice.toFixed(2),
                    Qty: sellQty.toFixed(6), Amount: proceeds.toFixed(2), PnL: (proceeds - (sellQty * holdings[ticker].costBasis)).toFixed(2),
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp, ticker).toFixed(2),
                    Reason: currentPrice < holdings[ticker].trailingStop ? "TRAILING_STOP_HIT" : "STRATEGY_EXIT"
                });
                delete holdings[ticker];
            } else {
                holdings[ticker].lastPrice = currentPrice;
            }
        }

        if (cash > 1.00) {
            let signals = [];
            for (const ticker of TICKERS) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 50) continue;
                const lastClose = history[history.length - 1].c;
                const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
                const rsi = calculateRSI(history.map(h => h.c));
                const roc = (lastClose - history[history.length - 50].c) / history[history.length - 50].c;

                if (isDangerRegime) {
                    if ((ticker === 'PSQ' && lastClose > sma20) || (rsi < 25)) signals.push({ ticker, price: lastClose, rsi, roc, type: "SNIPE" });
                } else {
                    if ((lastClose > sma20 && rsi < 70) || rsi < 35) signals.push({ ticker, price: lastClose, rsi, roc, type: "MOMENTUM" });
                }
            }
            signals.sort((a, b) => b.roc - a.roc);
            const maxSlots = isDangerRegime ? 1 : 3;
            const signalsToBuy = signals.slice(0, maxSlots);
            const riskWeight = isDangerRegime ? 0.3 : sentiment.riskWeight;
            const maxSpend = (cash * riskWeight) / Math.max(1, signalsToBuy.length);

            for (const sig of signalsToBuy) {
                const spend = Math.min(cash, maxSpend);
                const actualCost = spend * (1 + SLIPPAGE);
                const qty = spend / sig.price;
                const history = allData[sig.ticker].filter(b => b.t < timestamp);
                const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
                const stdDev = Math.sqrt(history.slice(-20).reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
                holdings[sig.ticker] = { qty, costBasis: sig.price, trailingStop: sig.price - (sentiment.stopMultiplier * stdDev), lastPrice: sig.price };
                cash -= actualCost;
                ledger.push({
                    Date: dayStr, Ticker: sig.ticker, Action: "BUY", Price: sig.price.toFixed(2),
                    Qty: holdings[sig.ticker].qty.toFixed(6), Amount: spend.toFixed(2), PnL: "0.00",
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp).toFixed(2),
                    Reason: `v11_RS_${sig.type}`
                });
            }
        }

        if (isMonthEnd) {
            const currentTotalVal = cash + calculateVal(holdings, allData, timestamp);
            if (currentTotalVal > monthStartValue) {
                const harvestAmount = (currentTotalVal - monthStartValue) * 0.20;
                reserve += harvestAmount;
                cash -= Math.min(cash, harvestAmount);
                ledger.push({
                    Date: dayStr, Ticker: "PORTFOLIO", Action: "PROFIT_HARVEST",
                    Price: "0.00", Qty: "0.00", Amount: harvestAmount.toFixed(2), PnL: "0.00",
                    Cash_On_Hand: "RESERVE", Invested_Value: (currentTotalVal - harvestAmount).toFixed(2),
                    Reason: "v11 20/80 Harvest"
                });
            }
            monthStartValue = cash + calculateVal(holdings, allData, timestamp);
        }
    }

    const finalVal = cash + calculateVal(holdings, allData, tradingDays[tradingDays.length-1]);
    const csvHeader = "Date,Ticker,Action,Price,Qty,Amount,PnL,Cash_On_Hand,Invested_Value,Reason";
    const csvRows = ledger.map(t => `${t.Date},${t.Ticker},${t.Action},${t.Price},${t.Qty},${t.Amount},${t.PnL},${t.Cash_On_Hand},${t.Invested_Value},"${t.Reason}"`);
    const csvPath = path.join(__dirname, '..', 'reports', 'Ultron_2016_v11_Hybrid.csv');
    fs.writeFileSync(csvPath, [csvHeader, ...csvRows].join('\n'));
    console.log(`CSV_GENERATED:${csvPath}`);
    console.log(`V11_2016_FINAL_ACTIVE:${finalVal.toFixed(2)}`);
    console.log(`V11_2016_TOTAL_RESERVE:${reserve.toFixed(2)}`);
}

function calculateVal(holdings, allData, timestamp, excludeTicker = null) {
    let v = 0;
    for (const t in holdings) {
        if (t === excludeTicker) continue;
        const bar = allData[t].find(b => b.t === timestamp);
        v += holdings[t].qty * (bar ? bar.c : holdings[t].lastPrice);
    }
    return v;
}

function isLastTradingDayOfMonth(dateStr, allDays) {
    const month = dateStr.substring(0, 7);
    const monthDays = allDays.filter(d => d.startsWith(month));
    return monthDays[monthDays.length - 1].startsWith(dateStr);
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

run2016V11Simulation();
