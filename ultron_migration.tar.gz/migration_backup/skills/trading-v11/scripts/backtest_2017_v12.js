const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const { getMacroSentiment } = require('../references/sentiment_overlay');
const { detectRegime } = require('../references/regime_detector');

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META", "PSQ"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

function calculateRSI(prices, period = 14) {
    if (prices.length <= period) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
        const diff = prices[prices.length - i] - prices[prices.length - i - 1];
        if (diff >= 0) gains += diff; else losses -= diff;
    }
    const avgGain = gains / period, avgLoss = losses / period;
    return avgLoss === 0 ? 100 : 100 - (100 / (1 + (avgGain / avgLoss)));
}

async function run2017V12Redemption() {
    console.log(`Starting v12 "Dynamic Conviction" Simulation (2017)...`);
    
    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2016-06-01T00:00:00Z', '2018-01-05T23:59:59Z');
    }

    const tradingDays = allData["AAPL"]
        .filter(b => b.t >= '2017-01-01T00:00:00Z' && b.t <= '2017-12-31T23:59:59Z')
        .map(b => b.t);

    let cash = 1000.00; 
    let holdings = {}; 
    let reserve = 0.00; 
    let monthStartValue = 1000.00;
    const ledger = [];
    const SLIPPAGE = 0.0005;

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        const isMonthEnd = isLastTradingDayOfMonth(dayStr, tradingDays);

        // --- REGIME DETECTION (The v12 Brain) ---
        const marketHistory = allData["MSFT"].filter(b => b.t < timestamp);
        const sma200 = marketHistory.slice(-200).reduce((acc, val) => acc + val.c, 0) / 200;
        const prices20 = marketHistory.slice(-20).map(b => b.c);
        const avg20 = prices20.reduce((a,b) => a+b, 0) / 20;
        const stdDev20 = Math.sqrt(prices20.reduce((a,b) => a + Math.pow(b - avg20, 2), 0) / 20);
        
        const regime = detectRegime(prices20, sma200, stdDev20);

        // v12 DYNAMIC PARAMETERS
        let stopMult = 1.2;
        let harvestRate = 0.20;
        let riskWeight = 1.0;

        if (regime === "CHOPPY_BULL" || regime === "SIDEWAYS_ACCUMULATION") {
            stopMult = 2.0; // Wide stops for choppy markets
            riskWeight = 0.6; // Reduced exposure
        } else if (regime === "BULL_TRENDING") {
            stopMult = 1.1; // Tight stops for clear trends
            harvestRate = 0.05; // Keep capital in the engine (v12 logic)
            riskWeight = 1.2; // Aggressive compounding
        }

        // 1. EXIT LOGIC
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;
            const currentPrice = dayBar.c;

            const history = allData[ticker].filter(b => b.t < timestamp);
            const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
            const rsi = calculateRSI(history.map(h => h.c));
            
            // v12 Volatility Protection: Trailing Stop OR Hard Floor (7%)
            const hardFloor = holdings[ticker].costBasis * 0.93;
            const trailingStop = currentPrice - (stopMult * stdDev20);
            if (trailingStop > holdings[ticker].trailingStop) holdings[ticker].trailingStop = trailingStop;

            // Sell if we hit the better of the two stops, OR momentum breaks
            if (currentPrice < Math.max(holdings[ticker].trailingStop, hardFloor) || currentPrice < sma20 || rsi > 78) {
                const sellQty = holdings[ticker].qty;
                const proceeds = (sellQty * currentPrice) * (1 - SLIPPAGE);
                cash += proceeds;
                ledger.push({
                    Date: dayStr, Ticker: ticker, Action: "SELL", Price: currentPrice.toFixed(2),
                    Qty: sellQty.toFixed(6), Amount: proceeds.toFixed(2), PnL: (proceeds - (sellQty * holdings[ticker].costBasis)).toFixed(2),
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp, ticker).toFixed(2),
                    Reason: currentPrice < hardFloor ? "HARD_FLOOR_HIT" : (rsi > 78 ? "PROFIT_TAKE" : "REGIME_EXIT")
                });
                delete holdings[ticker];
            } else {
                holdings[ticker].lastPrice = currentPrice;
            }
        }

        // 2. ENTRY LOGIC
        if (cash > 1.00) {
            let signals = [];
            for (const ticker of TICKERS) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 50) continue;
                const lastClose = history[history.length - 1].c;
                const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
                const rsi = calculateRSI(history.map(h => h.c));
                
                // v12 Entry Filter: Price > SMA20 + RSI Check + Volatility Contraction (Quiet Before Breakout)
                if (lastClose > sma20 && rsi < 65) {
                    const volHistory = history.slice(-5).map(b => (b.h - b.l) / b.c);
                    const avgVol = volHistory.reduce((a,b) => a+b, 0) / 5;
                    const isQuiet = avgVol < 0.02; // Less than 2% daily range average

                    if (isQuiet) {
                        const roc = (lastClose - history[history.length - 50].c) / history[history.length - 50].c;
                        signals.push({ ticker, price: lastClose, roc });
                    }
                }
            }
            signals.sort((a, b) => b.roc - a.roc);
            const maxSlots = 3;
            const signalsToBuy = signals.slice(0, maxSlots);
            const maxSpend = (cash * riskWeight) / Math.max(1, signalsToBuy.length);

            for (const sig of signalsToBuy) {
                const spend = Math.min(cash, maxSpend);
                const actualCost = spend * (1 + SLIPPAGE);
                holdings[sig.ticker] = { qty: spend / sig.price, costBasis: sig.price, trailingStop: sig.price * 0.90, lastPrice: sig.price };
                cash -= actualCost;
                ledger.push({
                    Date: dayStr, Ticker: sig.ticker, Action: "BUY", Price: sig.price.toFixed(2),
                    Qty: holdings[sig.ticker].qty.toFixed(6), Amount: spend.toFixed(2), PnL: "0.00",
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp).toFixed(2),
                    Reason: `v12_${regime}`
                });
            }
        }

        if (isMonthEnd) {
            const currentTotalVal = cash + calculateVal(holdings, allData, timestamp);
            if (currentTotalVal > monthStartValue && harvestRate > 0) {
                const harvestAmount = (currentTotalVal - monthStartValue) * harvestRate;
                reserve += harvestAmount;
                cash -= Math.min(cash, harvestAmount);
                ledger.push({
                    Date: dayStr, Ticker: "PORTFOLIO", Action: "PROFIT_HARVEST",
                    Price: "0.00", Qty: "0.00", Amount: harvestAmount.toFixed(2), PnL: "0.00",
                    Cash_On_Hand: "RESERVE", Invested_Value: (currentTotalVal - harvestAmount).toFixed(2),
                    Reason: `v12 ${harvestRate*100}% Harvest`
                });
            }
            monthStartValue = cash + calculateVal(holdings, allData, timestamp);
        }
    }

    const finalVal = cash + calculateVal(holdings, allData, tradingDays[tradingDays.length-1]);
    const csvHeader = "Date,Ticker,Action,Price,Qty,Amount,PnL,Cash_On_Hand,Invested_Value,Reason";
    const csvRows = ledger.map(t => `${t.Date},${t.Ticker},${t.Action},${t.Price},${t.Qty},${t.Amount},${t.PnL},${t.Cash_On_Hand},${t.Invested_Value},"${t.Reason}"`);
    const csvPath = path.join(__dirname, '..', 'reports', 'Ultron_2017_v12_Dynamic.csv');
    fs.writeFileSync(csvPath, [csvHeader, ...csvRows].join('\n'));
    console.log(`V12_2017_FINAL_ACTIVE:${finalVal.toFixed(2)}`);
    console.log(`V11_2017_TOTAL_RESERVE:${reserve.toFixed(2)}`);
}

function calculateVal(holdings, allData, timestamp, excludeTicker = null) {
    let v = 0;
    for (const t in holdings) {
        if (t === excludeTicker) continue;
        const bar = allData[t].find(b => b.t === timestamp);
        v += holdings[t].qty * (bar ? bar.c : holdings[t].lastPrice);
    }
    return v;
}

function isLastTradingDayOfMonth(dateStr, allDays) {
    const month = dateStr.substring(0, 7);
    const monthDays = allDays.filter(d => d.startsWith(month));
    return monthDays[monthDays.length - 1].startsWith(dateStr);
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

run2017V12Redemption();
