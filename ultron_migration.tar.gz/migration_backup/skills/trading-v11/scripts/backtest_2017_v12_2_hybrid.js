const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const { detectRegime } = require('../references/regime_detector');
const { calculateDividends } = require('../references/dividend_yields');

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META", "PSQ"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

function calculateRSI(prices, period = 14) {
    if (prices.length <= period) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
        const diff = prices[prices.length - i] - prices[prices.length - i - 1];
        if (diff >= 0) gains += diff; else losses -= diff;
    }
    const avgGain = gains / period, avgLoss = losses / period;
    return avgLoss === 0 ? 100 : 100 - (100 / (1 + (avgGain / avgLoss)));
}

async function run2017V12_2_Hybrid() {
    console.log(`Starting v12.2 "Hybrid 40" Simulation (2017)...`);
    
    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2016-06-01T00:00:00Z', '2018-01-05T23:59:59Z');
    }

    const tradingDays = allData["AAPL"]
        .filter(b => b.t >= '2017-01-01T00:00:00Z' && b.t <= '2017-12-31T23:59:59Z')
        .map(b => b.t);

    let cash = 1038.90; 
    let holdings = {}; 
    let reserve = 51.58; // Current total reserve
    let monthStartValue = cash;
    let totalDividends = 0;
    const ledger = [];
    const SLIPPAGE = 0.0005;

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        const isMonthEnd = isLastTradingDayOfMonth(dayStr, tradingDays);

        const marketHistory = allData["MSFT"].filter(b => b.t < timestamp);
        const sma200 = marketHistory.slice(-200).reduce((acc, val) => acc + val.c, 0) / 200;
        const prices20 = marketHistory.slice(-20).map(b => b.c);
        const avg20 = prices20.reduce((a,b) => a+b, 0) / 20;
        const stdDev20 = Math.sqrt(prices20.reduce((a,b) => a + Math.pow(b - avg20, 2), 0) / 20);
        
        const regime = detectRegime(prices20, sma200, stdDev20);

        // v12.2 HYBRID 40 PARAMETERS
        let stopMult = (regime === "CHOPPY_BULL") ? 2.0 : 1.5;
        let riskWeight = (regime === "BULL_TRENDING") ? 1.3 : 0.8; 
        let harvestRate = 0.05; // Constant Safety Valve (5%)

        // 1. EXIT LOGIC & DIVIDEND ACCRUAL
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;
            const currentPrice = dayBar.c;
            
            // Accrue daily estimated dividend
            const dailyDiv = calculateDividends(ticker, holdings[ticker].qty * currentPrice, 1);
            totalDividends += dailyDiv;
            cash += dailyDiv; // Reinvest dividends immediately into cash

            const history = allData[ticker].filter(b => b.t < timestamp);
            const rsi = calculateRSI(history.map(h => h.c));
            
            const hardFloor = holdings[ticker].costBasis * 0.93; // 7% Safety Shield
            const trailingStop = currentPrice - (stopMult * stdDev20);
            if (trailingStop > holdings[ticker].trailingStop) holdings[ticker].trailingStop = trailingStop;

            if (currentPrice < Math.max(holdings[ticker].trailingStop, hardFloor) || rsi > 82) {
                const sellQty = holdings[ticker].qty;
                const proceeds = (sellQty * currentPrice) * (1 - SLIPPAGE);
                cash += proceeds;
                ledger.push({
                    Date: dayStr, Ticker: ticker, Action: "SELL", Price: currentPrice.toFixed(2),
                    Qty: sellQty.toFixed(6), Amount: proceeds.toFixed(2), PnL: (proceeds - (sellQty * holdings[ticker].costBasis)).toFixed(2),
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp, ticker).toFixed(2),
                    Reason: rsi > 82 ? "RSI_ULTRA_EXHAUSTION" : "STOP_LOSS_SHIELD"
                });
                delete holdings[ticker];
            } else {
                // Progressive Pyramiding (v12.2)
                const currentGain = (currentPrice - holdings[ticker].costBasis) / holdings[ticker].costBasis;
                if (currentGain > 0.05 && !holdings[ticker].pyramid1 && cash > 50) {
                    const buyAmt = cash * 0.15; // Add 15% of available cash
                    holdings[ticker].qty += buyAmt / currentPrice;
                    holdings[ticker].pyramid1 = true;
                    cash -= buyAmt * (1 + SLIPPAGE);
                } else if (currentGain > 0.15 && !holdings[ticker].pyramid2 && cash > 50) {
                    const buyAmt = cash * 0.15;
                    holdings[ticker].qty += buyAmt / currentPrice;
                    holdings[ticker].pyramid2 = true;
                    cash -= buyAmt * (1 + SLIPPAGE);
                }
                holdings[ticker].lastPrice = currentPrice;
            }
        }

        // 2. ENTRY LOGIC (High-Delta Concentration)
        if (cash > 20.00) {
            let signals = [];
            for (const ticker of TICKERS) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 50) continue;
                const lastClose = history[history.length - 1].c;
                const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
                const rsi = calculateRSI(history.map(h => h.c));
                
                if (lastClose > sma20 && rsi < 60) {
                    const roc = (lastClose - history[history.length - 50].c) / history[history.length - 50].c;
                    signals.push({ ticker, price: lastClose, roc });
                }
            }
            signals.sort((a, b) => b.roc - a.roc);
            
            // "Sniper" Rule: Put more weight in the #1 signal
            const signalsToBuy = signals.slice(0, 2);
            if (signalsToBuy.length > 0) {
                const weights = (signalsToBuy.length === 1) ? [1.0] : [0.7, 0.3];
                for (let i = 0; i < signalsToBuy.length; i++) {
                    const spend = cash * weights[i] * riskWeight;
                    if (spend < 10) continue;
                    holdings[signalsToBuy[i].ticker] = { qty: spend / signalsToBuy[i].price, costBasis: signalsToBuy[i].price, trailingStop: signalsToBuy[i].price * 0.90, lastPrice: signalsToBuy[i].price };
                    cash -= spend * (1 + SLIPPAGE);
                    ledger.push({
                        Date: dayStr, Ticker: signalsToBuy[i].ticker, Action: "BUY", Price: signalsToBuy[i].price.toFixed(2),
                        Qty: holdings[signalsToBuy[i].ticker].qty.toFixed(6), Amount: spend.toFixed(2), PnL: "0.00",
                        Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp).toFixed(2),
                        Reason: "v12.2 Hybrid Entry"
                    });
                }
            }
        }

        if (isMonthEnd) {
            const currentTotalVal = cash + calculateVal(holdings, allData, timestamp);
            if (currentTotalVal > monthStartValue) {
                const harvestAmount = (currentTotalVal - monthStartValue) * harvestRate;
                reserve += harvestAmount;
                cash -= Math.min(cash, harvestAmount);
            }
            monthStartValue = cash + calculateVal(holdings, allData, timestamp);
        }
    }

    const finalVal = cash + calculateVal(holdings, allData, tradingDays[tradingDays.length-1]);
    const csvHeader = "Date,Ticker,Action,Price,Qty,Amount,PnL,Cash_On_Hand,Invested_Value,Reason";
    const csvRows = ledger.map(t => `${t.Date},${t.Ticker},${t.Action},${t.Price},${t.Qty},${t.Amount},${t.PnL},${t.Cash_On_Hand},${t.Invested_Value},"${t.Reason}"`);
    const csvPath = path.join(__dirname, '..', 'reports', 'Ultron_2017_v12_2_Hybrid.csv');
    fs.writeFileSync(csvPath, [csvHeader, ...csvRows].join('\n'));
    console.log(`V12_2_2017_ACTIVE:${finalVal.toFixed(2)}`);
    console.log(`V12_2_2017_RESERVE_TOTAL:${reserve.toFixed(2)}`);
    console.log(`V12_2_2017_EST_DIVIDENDS:${totalDividends.toFixed(2)}`);
}

function calculateVal(holdings, allData, timestamp, excludeTicker = null) {
    let v = 0;
    for (const t in holdings) {
        if (t === excludeTicker) continue;
        const bar = allData[t].find(b => b.t === timestamp);
        v += holdings[t].qty * (bar ? bar.c : holdings[t].lastPrice);
    }
    return v;
}

function isLastTradingDayOfMonth(dateStr, allDays) {
    const month = dateStr.substring(0, 7);
    const monthDays = allDays.filter(d => d.startsWith(month));
    return monthDays[monthDays.length - 1].startsWith(dateStr);
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

run2017V12_2_Hybrid();
