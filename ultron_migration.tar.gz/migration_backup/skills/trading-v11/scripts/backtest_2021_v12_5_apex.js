const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const { detectRegime } = require('../references/regime_detector');
const { calculateDividends } = require('../references/dividend_yields');

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META", "PSQ"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

function calculateRSI(prices, period = 14) {
    if (prices.length <= period) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
        const diff = prices[prices.length - i] - prices[prices.length - i - 1];
        if (diff >= 0) gains += diff; else losses -= diff;
    }
    const avgGain = gains / period, avgLoss = losses / period;
    return avgLoss === 0 ? 100 : 100 - (100 / (1 + (avgGain / avgLoss)));
}

async function run2021V12_5_Apex() {
    console.log(`Starting v12.5 "Apex" (Dynamic Universe + Inverse Weighting) for 2021...`);
    
    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2020-06-01T00:00:00Z', '2022-01-05T23:59:59Z');
    }

    const tradingDays = allData["AAPL"]
        .filter(b => b.t >= '2021-01-01T00:00:00Z' && b.t <= '2021-12-31T23:59:59Z')
        .map(b => b.t);

    let cash = 1430.31; 
    let holdings = {}; 
    let reserve = 127.54; 
    let monthStartValue = cash;
    const ledger = [];
    const SLIPPAGE = 0.0005;

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        const isMonthEnd = isLastTradingDayOfMonth(dayStr, tradingDays);

        const marketHistory = allData["MSFT"].filter(b => b.t < timestamp);
        const sma200 = marketHistory.slice(-200).reduce((acc, val) => acc + val.c, 0) / 200;
        const prices20 = marketHistory.slice(-20).map(b => b.c);
        const avg20 = prices20.reduce((a,b) => a+b, 0) / 20;
        const stdDev20 = Math.sqrt(prices20.reduce((a,b) => a + Math.pow(b - avg20, 2), 0) / 20);
        
        const regime = detectRegime(prices20, sma200, stdDev20);

        // v12.5 APEX PARAMETERS
        let stopMult = (regime === "BULL_TRENDING") ? 1.5 : 2.5; // Extreme noise filtering in choppy markets
        let riskWeight = (regime === "BULL_TRENDING") ? 1.5 : 0.4; // Very defensive when not in a clear trend
        let harvestRate = 0.02; // Minimal drag

        // 1. EXIT LOGIC
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;
            const currentPrice = dayBar.c;
            
            cash += calculateDividends(ticker, holdings[ticker].qty * currentPrice, 1);

            const history = allData[ticker].filter(b => b.t < timestamp);
            const rsi = calculateRSI(history.map(h => h.c));
            const hardFloor = holdings[ticker].costBasis * 0.90; 
            const trailingStop = currentPrice - (stopMult * stdDev20);
            if (trailingStop > holdings[ticker].trailingStop) holdings[ticker].trailingStop = trailingStop;

            if (currentPrice < Math.max(holdings[ticker].trailingStop, hardFloor) || rsi > 85) {
                const sellQty = holdings[ticker].qty;
                const proceeds = (sellQty * currentPrice) * (1 - SLIPPAGE);
                cash += proceeds;
                ledger.push({
                    Date: dayStr, Ticker: ticker, Action: "SELL", Price: currentPrice.toFixed(2),
                    Qty: sellQty.toFixed(6), Amount: proceeds.toFixed(2), PnL: (proceeds - (sellQty * holdings[ticker].costBasis)).toFixed(2),
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp, ticker).toFixed(2),
                    Reason: rsi > 85 ? "RSI_LIMIT" : "STOP_OUT"
                });
                delete holdings[ticker];
            } else {
                holdings[ticker].lastPrice = currentPrice;
            }
        }

        // 2. ENTRY LOGIC: Dynamic Universe (XOM/JPM Pivot)
        if (cash > 20.00) {
            let signals = [];
            for (const ticker of TICKERS) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 50) continue;
                const lastClose = history[history.length - 1].c;
                const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
                const rsi = calculateRSI(history.map(h => h.c));
                
                // v12.5 DYNAMIC PIVOT:
                // If Tech is failing but Energy (XOM) or Banks (JPM) are rising, follow the money.
                if (lastClose > sma20 && rsi > 45 && rsi < 75) {
                    const roc20 = (lastClose - history[history.length - 21].c) / history[history.length - 21].c;
                    if (roc20 > 0.03) signals.push({ ticker, price: lastClose, roc: roc20 });
                }
            }
            
            // Prioritize the top "non-correlated" signal
            signals.sort((a, b) => b.roc - a.roc);
            const signalsToBuy = signals.slice(0, 1);
            
            for (const sig of signalsToBuy) {
                const spend = cash * riskWeight;
                if (spend < 50) continue;
                holdings[sig.ticker] = { qty: spend / sig.price, costBasis: sig.price, trailingStop: sig.price * 0.88, lastPrice: sig.price };
                cash -= spend * (1 + SLIPPAGE);
                ledger.push({
                    Date: dayStr, Ticker: sig.ticker, Action: "BUY", Price: sig.price.toFixed(2),
                    Qty: holdings[sig.ticker].qty.toFixed(6), Amount: spend.toFixed(2), PnL: "0.00",
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp).toFixed(2),
                    Reason: "v12.5 Apex Entry"
                });
            }
        }

        if (isMonthEnd) {
            const currentTotalVal = cash + calculateVal(holdings, allData, timestamp);
            if (currentTotalVal > monthStartValue) {
                const harvestAmount = (currentTotalVal - monthStartValue) * harvestRate;
                reserve += harvestAmount;
                cash -= Math.min(cash, harvestAmount);
            }
            monthStartValue = cash + calculateVal(holdings, allData, timestamp);
        }
    }

    const finalVal = cash + calculateVal(holdings, allData, tradingDays[tradingDays.length-1]);
    const csvHeader = "Date,Ticker,Action,Price,Qty,Amount,PnL,Cash_On_Hand,Invested_Value,Reason";
    const csvRows = ledger.map(t => `${t.Date},${t.Ticker},${t.Action},${t.Price},${t.Qty},${t.Amount},${t.PnL},${t.Cash_On_Hand},${t.Invested_Value},"${t.Reason}"`);
    const csvPath = path.join(__dirname, '..', 'reports', 'Ultron_2021_v12_5_Apex.csv');
    fs.writeFileSync(csvPath, [csvHeader, ...csvRows].join('\n'));
    console.log(`V12_5_2021_ACTIVE:${finalVal.toFixed(2)}`);
    console.log(`V12_5_2021_RESERVE_TOTAL:${reserve.toFixed(2)}`);
}

function calculateVal(holdings, allData, timestamp, excludeTicker = null) {
    let v = 0;
    for (const t in holdings) {
        if (t === excludeTicker) continue;
        const bar = allData[t].find(b => b.t === timestamp);
        v += holdings[t].qty * (bar ? bar.c : holdings[t].lastPrice);
    }
    return v;
}

function isLastTradingDayOfMonth(dateStr, allDays) {
    const month = dateStr.substring(0, 7);
    const monthDays = allDays.filter(d => d.startsWith(month));
    return monthDays[monthDays.length - 1].startsWith(dateStr);
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

run2021V12_5_Apex();
