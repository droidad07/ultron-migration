const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

function calculateRSI(prices, period = 14) {
    if (prices.length <= period) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
        const diff = prices[prices.length - i] - prices[prices.length - i - 1];
        if (diff >= 0) gains += diff; else losses -= diff;
    }
    const avgGain = gains / period, avgLoss = losses / period;
    return avgLoss === 0 ? 100 : 100 - (100 / (1 + (avgGain / avgLoss)));
}

async function run2021V9Backtest() {
    console.log(`Starting 2021 Validation: v9 Hybrid Strategy (20/80 Harvest)...`);

    // Fetch data for all of 2021 (and late 2020 for lookback)
    const allData = {};
    for (const ticker of TICKERS) {
        // Optimized: Single API call per ticker for the entire year
        allData[ticker] = await fetchAlpacaBars(ticker, '2020-11-01T00:00:00Z', '2022-01-05T23:59:59Z');
    }

    const firstTicker = TICKERS.find(t => allData[t] && allData[t].length > 0);
    const tradingDays = allData[firstTicker]
        .filter(b => b.t >= '2021-01-01T00:00:00Z' && b.t <= '2021-12-31T23:59:59Z')
        .map(b => b.t);

    let cash = 100.00; 
    let holdings = {}; 
    let reserve = 0.00;
    let monthStartValue = 100.00;
    const ledger = [];

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        const isMonthEnd = isLastTradingDayOfMonth(dayStr, tradingDays);

        // 1. DYNAMIC ADJUSTMENT + EXIT LOGIC
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;

            const currentPrice = dayBar.c;
            const prevPrice = holdings[ticker].lastPrice;
            
            // AUTOMATIC CORPORATE ACTION ADJUSTMENT
            const change = (currentPrice - prevPrice) / prevPrice;
            if (Math.abs(change) > 0.40) {
                const ratio = prevPrice / currentPrice;
                const roundedRatio = Math.round(ratio);
                if (Math.abs(ratio - roundedRatio) < 0.2) {
                   holdings[ticker].qty *= roundedRatio;
                   holdings[ticker].costBasis /= roundedRatio;
                   ledger.push({ Date: dayStr, Ticker: ticker, Action: "AUTO_ADJUST", Price: currentPrice.toFixed(2), Qty: holdings[ticker].qty.toFixed(6), Amount: "0.00", PnL: "0.00", Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp).toFixed(2), Reason: `Auto-adjusted for ${roundedRatio}:1 Event` });
                }
            }
            holdings[ticker].lastPrice = currentPrice;

            const history = allData[ticker].filter(b => b.t < timestamp);
            const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
            const stdDev = Math.sqrt(history.slice(-20).reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
            const stopLoss = holdings[ticker].costBasis - (1.5 * stdDev);
            const rsi = calculateRSI(history.map(h => h.c));

            if (currentPrice < sma20 || currentPrice < stopLoss || rsi > 75) {
                const sellQty = holdings[ticker].qty;
                const proceeds = sellQty * currentPrice;
                const pnl = proceeds - (sellQty * holdings[ticker].costBasis);
                cash += proceeds;
                
                ledger.push({
                    Date: dayStr, Ticker: ticker, Action: "SELL", Price: currentPrice.toFixed(2),
                    Qty: sellQty.toFixed(6), Amount: proceeds.toFixed(2), PnL: pnl.toFixed(2),
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp, ticker).toFixed(2),
                    Reason: currentPrice < stopLoss ? "STOP_HIT" : (rsi > 75 ? "PROFIT_TAKE_RSI" : "MOMENTUM_LOSS")
                });
                delete holdings[ticker];
            }
        }

        // 2. ENTRY LOGIC (3 Slots)
        if (cash > 1.00) {
            let signals = [];
            for (const ticker of TICKERS) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 20) continue;
                const lastClose = history[history.length - 1].c;
                const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
                const rsi = calculateRSI(history.map(h => h.c));
                if ((lastClose > sma20 && rsi < 70) || (rsi < 35)) signals.push({ ticker, price: lastClose, rsi, type: rsi < 35 ? "DIP" : "MOMENTUM" });
            }
            const signalsToBuy = signals.slice(0, 3);
            const maxSpend = cash / Math.max(1, signalsToBuy.length);
            for (const sig of signalsToBuy) {
                const spend = Math.min(cash, maxSpend);
                holdings[sig.ticker] = { qty: spend / sig.price, costBasis: sig.price, lastPrice: sig.price };
                cash -= spend;
                ledger.push({
                    Date: dayStr, Ticker: sig.ticker, Action: "BUY", Price: sig.price.toFixed(2),
                    Qty: holdings[sig.ticker].qty.toFixed(6), Amount: spend.toFixed(2), PnL: "0.00",
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp).toFixed(2),
                    Reason: `v9_${sig.type}_RSI(${sig.rsi.toFixed(1)})`
                });
            }
        }

        // 3. MONTH END HARVEST
        if (isMonthEnd) {
            const currentTotalVal = cash + calculateVal(holdings, allData, timestamp);
            if (currentTotalVal > monthStartValue) {
                const harvestAmount = (currentTotalVal - monthStartValue) * 0.20;
                reserve += harvestAmount;
                if (cash >= harvestAmount) { cash -= harvestAmount; } 
                else {
                    const shortfall = harvestAmount - cash; cash = 0;
                    const totalInvested = calculateVal(holdings, allData, timestamp);
                    for (const ticker in holdings) {
                        const dayBar = allData[ticker].find(b => b.t === timestamp);
                        const weight = (holdings[ticker].qty * dayBar.c) / totalInvested;
                        holdings[ticker].qty -= (shortfall * weight) / dayBar.c;
                    }
                }
                ledger.push({
                    Date: dayStr, Ticker: "PORTFOLIO", Action: "PROFIT_HARVEST",
                    Price: "0.00", Qty: "0.00", Amount: harvestAmount.toFixed(2), PnL: "0.00",
                    Cash_On_Hand: "RESERVE", Invested_Value: (currentTotalVal - harvestAmount).toFixed(2),
                    Reason: "v9 20% Growth Locked"
                });
            }
            monthStartValue = cash + calculateVal(holdings, allData, timestamp);
        }
    }

    const finalVal = cash + calculateVal(holdings, allData, tradingDays[tradingDays.length-1]);
    const csvHeader = "Date,Ticker,Action,Price,Qty,Amount,PnL,Cash_On_Hand,Invested_Value,Reason";
    const csvRows = ledger.map(t => `${t.Date},${t.Ticker},${t.Action},${t.Price},${t.Qty},${t.Amount},${t.PnL},${t.Cash_On_Hand},${t.Invested_Value},"${t.Reason}"`);
    fs.writeFileSync(path.join(__dirname, 'Ultron_2021_v9_Final_Validation.csv'), [csvHeader, ...csvRows].join('\n'));
    console.log(`FINAL_BALANCE:${finalVal.toFixed(2)}`);
    console.log(`RESERVE_CASH:${reserve.toFixed(2)}`);
}

function calculateVal(holdings, allData, timestamp, excludeTicker = null) {
    let v = 0;
    for (const t in holdings) {
        if (t === excludeTicker) continue;
        const bar = allData[t].find(b => b.t === timestamp);
        v += holdings[t].qty * (bar ? bar.c : holdings[t].lastPrice);
    }
    return v;
}

function isLastTradingDayOfMonth(dateStr, allDays) {
    const month = dateStr.substring(0, 7);
    const monthDays = allDays.filter(d => d.startsWith(month));
    return monthDays[monthDays.length - 1].startsWith(dateStr);
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

run2021V9Backtest();
