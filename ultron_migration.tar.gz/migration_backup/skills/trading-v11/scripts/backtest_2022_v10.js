const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META", "PSQ"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

function calculateRSI(prices, period = 14) {
    if (prices.length <= period) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
        const diff = prices[prices.length - i] - prices[prices.length - i - 1];
        if (diff >= 0) gains += diff; else losses -= diff;
    }
    const avgGain = gains / period, avgLoss = losses / period;
    return avgLoss === 0 ? 100 : 100 - (100 / (1 + (avgGain / avgLoss)));
}

async function run2022V10Adaptive() {
    console.log(`Starting 2022 RE-TEST: v10 Adaptive Shield (SMA200 + Inverses)...`);

    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2021-01-01T00:00:00Z', '2023-01-05T23:59:59Z');
    }

    const tradingDays = allData["AAPL"]
        .filter(b => b.t >= '2022-01-01T00:00:00Z' && b.t <= '2022-12-31T23:59:59Z')
        .map(b => b.t);

    let cash = 223.15; // Starting active capital from end of 2021
    let holdings = {}; 
    let reserve = 70.46; // Reserve from 2021
    let monthStartValue = cash;
    const ledger = [];

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        const isMonthEnd = isLastTradingDayOfMonth(dayStr, tradingDays);

        // --- REGIME DETECTION (Market Gravity) ---
        // Using MSFT as a proxy for broad market trend if SPY data isn't in TICKERS
        const marketHistory = allData["MSFT"].filter(b => b.t < timestamp);
        const sma200 = marketHistory.slice(-200).reduce((acc, val) => acc + val.c, 0) / 200;
        const lastMarketPrice = marketHistory[marketHistory.length - 1].c;
        const isDangerRegime = lastMarketPrice < sma200;

        // 1. EXIT LOGIC
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;
            const currentPrice = dayBar.c;
            const history = allData[ticker].filter(b => b.t < timestamp);
            const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
            const stdDev = Math.sqrt(history.slice(-20).reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
            const stopLoss = holdings[ticker].costBasis - (1.2 * stdDev); // Tighter stops in V10
            const rsi = calculateRSI(history.map(h => h.c));

            if (currentPrice < sma20 || currentPrice < stopLoss || rsi > 75) {
                const sellQty = holdings[ticker].qty;
                const proceeds = sellQty * currentPrice;
                cash += proceeds;
                ledger.push({
                    Date: dayStr, Ticker: ticker, Action: "SELL", Price: currentPrice.toFixed(2),
                    Qty: sellQty.toFixed(6), Amount: proceeds.toFixed(2), PnL: (proceeds - (sellQty * holdings[ticker].costBasis)).toFixed(2),
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp, ticker).toFixed(2),
                    Reason: currentPrice < stopLoss ? "STOP_HIT" : "V10_REGIME_EXIT"
                });
                delete holdings[ticker];
            }
        }

        // 2. ENTRY LOGIC (Adaptive Sizing)
        if (cash > 1.00) {
            let signals = [];
            for (const ticker of TICKERS) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 20) continue;
                const lastClose = history[history.length - 1].c;
                const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
                const rsi = calculateRSI(history.map(h => h.c));

                // REGIME AWARE RULES
                if (isDangerRegime) {
                    // Only buy Inverse (PSQ) or Extreme Dips
                    if ((ticker === 'PSQ' && lastClose > sma20) || (rsi < 25)) {
                        signals.push({ ticker, price: lastClose, rsi, type: "DANGER_REGIME_SNIPE" });
                    }
                } else {
                    // Normal Momentum
                    if ((lastClose > sma20 && rsi < 70) || rsi < 35) {
                        signals.push({ ticker, price: lastClose, rsi, type: "NORMAL_MOMENTUM" });
                    }
                }
            }

            const maxSlots = isDangerRegime ? 1 : 3;
            const signalsToBuy = signals.slice(0, maxSlots);
            const riskWeight = isDangerRegime ? 0.3 : 1.0; // Reduce size by 70% in danger
            const maxSpend = (cash * riskWeight) / Math.max(1, signalsToBuy.length);

            for (const sig of signalsToBuy) {
                const spend = Math.min(cash, maxSpend);
                holdings[sig.ticker] = { qty: spend / sig.price, costBasis: sig.price, lastPrice: sig.price };
                cash -= spend;
                ledger.push({
                    Date: dayStr, Ticker: sig.ticker, Action: "BUY", Price: sig.price.toFixed(2),
                    Qty: holdings[sig.ticker].qty.toFixed(6), Amount: spend.toFixed(2), PnL: "0.00",
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateVal(holdings, allData, timestamp).toFixed(2),
                    Reason: sig.type
                });
            }
        }

        // 3. MONTH END HARVEST
        if (isMonthEnd) {
            const currentVal = cash + calculateVal(holdings, allData, timestamp);
            if (currentVal > monthStartValue) {
                const harvest = (currentVal - monthStartValue) * 0.20;
                reserve += harvest; cash -= Math.min(cash, harvest);
            }
            monthStartValue = cash + calculateVal(holdings, allData, timestamp);
        }
    }

    const finalVal = cash + calculateVal(holdings, allData, tradingDays[tradingDays.length-1]);
    const csvHeader = "Date,Ticker,Action,Price,Qty,Amount,PnL,Cash_On_Hand,Invested_Value,Reason";
    const csvRows = ledger.map(t => `${t.Date},${t.Ticker},${t.Action},${t.Price},${t.Qty},${t.Amount},${t.PnL},${t.Cash_On_Hand},${t.Invested_Value},"${t.Reason}"`);
    fs.writeFileSync(path.join(__dirname, 'Ultron_2022_v10_Adaptive_Shield.csv'), [csvHeader, ...csvRows].join('\n'));
    console.log(`V10_FINAL_VALUE:${finalVal.toFixed(2)}`);
    console.log(`V10_RESERVE:${reserve.toFixed(2)}`);
}

function calculateVal(holdings, allData, timestamp, excludeTicker = null) {
    let v = 0;
    for (const t in holdings) {
        if (t === excludeTicker) continue;
        const bar = allData[t].find(b => b.t === timestamp);
        v += holdings[t].qty * (bar ? bar.c : holdings[t].lastPrice);
    }
    return v;
}

function isLastTradingDayOfMonth(dateStr, allDays) {
    const month = dateStr.substring(0, 7);
    const monthDays = allDays.filter(d => d.startsWith(month));
    return monthDays[monthDays.length - 1].startsWith(dateStr);
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

run2022V10Adaptive();
