const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

// Diversified Tickers
const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function runAugustBacktest() {
    const tradingDays = [
        "2024-08-01", "2024-08-02", "2024-08-05", "2024-08-06", "2024-08-07",
        "2024-08-08", "2024-08-09", "2024-08-12", "2024-08-13", "2024-08-14",
        "2024-08-15", "2024-08-16", "2024-08-19", "2024-08-20", "2024-08-21",
        "2024-08-22", "2024-08-23", "2024-08-26", "2024-08-27", "2024-08-28",
        "2024-08-29", "2024-08-30"
    ];

    let totalPortfolioValue = 80.94; // Starting from July's close
    const dailyStats = [];

    console.log(`Analyzing August 2024 with Expanded Diversification (10 Tickers)...`);

    for (const day of tradingDays) {
        let dailyPnl = 0;
        let daySummary = { day, tickers: [] };

        for (const ticker of TICKERS) {
            const lookbackEnd = new Date(new Date(day).getTime() - (1 * 24 * 60 * 60 * 1000)).toISOString();
            const history = await fetchAlpacaBars(ticker, '2024-06-01T00:00:00Z', lookbackEnd);
            
            if (history.length < 20) continue;

            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const lastClose = history[history.length - 1].c;
            
            // Volatility Stop (2 * 20-day StdDev)
            const mean = sma20;
            const stdDev = Math.sqrt(window.reduce((acc, val) => acc + Math.pow(val.c - mean, 2), 0) / 20);
            const stopLoss = lastClose - (2 * stdDev);

            if (lastClose > sma20) {
                const actualDayData = await fetchAlpacaBars(ticker, day + 'T00:00:00Z', day + 'T23:59:59Z');
                if (actualDayData.length > 0) {
                    const actualClose = actualDayData[actualDayData.length - 1].c;
                    
                    if (Math.abs((actualClose - lastClose) / lastClose) > 0.5) continue;

                    const effectiveExit = actualClose < stopLoss ? stopLoss : actualClose;
                    const changePercent = (effectiveExit - lastClose) / lastClose;
                    
                    // Position size: 1/10th of portfolio
                    const positionSize = totalPortfolioValue / TICKERS.length;
                    const tradePnl = positionSize * changePercent;
                    
                    dailyPnl += tradePnl;
                    daySummary.tickers.push({ ticker, pnl: tradePnl.toFixed(2), change: (changePercent * 100).toFixed(2) + '%', exit: actualClose < stopLoss ? 'STOP_HIT' : 'CLOSE' });
                }
            }
        }

        totalPortfolioValue += dailyPnl;
        dailyStats.push({ day, pnl: dailyPnl.toFixed(2), total: totalPortfolioValue.toFixed(2), tickers: daySummary.tickers });

        await supabase.from('performance_metrics').insert({
            date: day,
            daily_pnl: dailyPnl,
            logic_version: 'SMA20_ATR_Diversified_v3',
            notes: JSON.stringify(daySummary.tickers)
        });
    }

    console.log("AUGUST_REPORT_START");
    console.log(JSON.stringify(dailyStats, null, 2));
    console.log("AUGUST_REPORT_END");
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runAugustBacktest();
