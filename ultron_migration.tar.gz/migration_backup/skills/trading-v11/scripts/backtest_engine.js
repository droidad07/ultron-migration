const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

/**
 * Unified Backtest Engine (v11 Precision Lock)
 * Parameters passed via environment variables or hardcoded for a single-turn month run.
 */

async function runBacktest(config) {
    const { start_date, end_date, initial_cash, initial_reserve, tickers } = config;
    console.log(`[ENGINE] Validating: ${start_date} to ${end_date} | Initial Active: $${initial_cash}`);

    const allData = {};
    for (const ticker of tickers) {
        // Fetch specific range plus lookback
        const lookbackStart = new Date(new Date(start_date).getTime() - (200 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0];
        allData[ticker] = await fetchAlpacaBars(ticker, lookbackStart, end_date);
    }

    const firstTicker = tickers.find(t => allData[t] && allData[t].length > 0);
    if (!firstTicker) return console.error("No data found.");

    const tradingDays = allData[firstTicker]
        .filter(b => b.t >= start_date + 'T00:00:00Z' && b.t <= end_date + 'T23:59:59Z')
        .map(b => b.t);

    let cash = parseFloat(initial_cash);
    let holdings = {};
    let reserve = parseFloat(initial_reserve);
    let monthStartValue = cash;
    const ledger = [];
    const SLIPPAGE = 0.0005;

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        const isMonthEnd = isLastTradingDayOfMonth(dayStr, tradingDays);

        // 1. EXIT LOGIC
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;
            const currentPrice = dayBar.c;
            const history = allData[ticker].filter(b => b.t < timestamp);
            const sma20 = calculateSMA(history, 20);
            const stdDev = calculateStdDev(history, 20, sma20);
            
            const potentialStop = currentPrice - (1.2 * stdDev);
            if (potentialStop > holdings[ticker].trailingStop) holdings[ticker].trailingStop = potentialStop;

            if (currentPrice < sma20 || currentPrice < holdings[ticker].trailingStop) {
                const proceeds = (holdings[ticker].qty * currentPrice) * (1 - SLIPPAGE);
                cash += proceeds;
                ledger.push({ Date: dayStr, Ticker: ticker, Action: "SELL", Price: currentPrice.toFixed(2), PnL: (proceeds - (holdings[ticker].qty * holdings[ticker].costBasis)).toFixed(2), Cash: cash.toFixed(2), Reason: "PRECISION_EXIT" });
                delete holdings[ticker];
            }
        }

        // 2. ENTRY LOGIC
        if (cash > 1.00) {
            let signals = [];
            for (const ticker of tickers) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 50) continue;
                const lastClose = history[history.length - 1].c;
                const sma20 = calculateSMA(history, 20);
                const roc = (lastClose - history[history.length - 50].c) / history[history.length - 50].c;

                if (lastClose > sma20) signals.push({ ticker, price: lastClose, roc });
            }
            signals.sort((a, b) => b.roc - a.roc);
            const maxSlots = 3;
            const signalsToBuy = signals.slice(0, maxSlots);
            const maxSpend = cash / Math.max(1, signalsToBuy.length);

            for (const sig of signalsToBuy) {
                const spend = Math.min(cash, maxSpend);
                const actualCost = spend * (1 + SLIPPAGE);
                const qty = spend / sig.price;
                const history = allData[sig.ticker].filter(b => b.t < timestamp);
                const sma20 = calculateSMA(history, 20);
                const stdDev = calculateStdDev(history, 20, sma20);

                holdings[sig.ticker] = { qty, costBasis: sig.price, trailingStop: sig.price - (1.2 * stdDev) };
                cash -= actualCost;
                ledger.push({ Date: dayStr, Ticker: sig.ticker, Action: "BUY", Price: sig.price.toFixed(2), PnL: "0.00", Cash: cash.toFixed(2), Reason: "MOMENTUM_RANKED" });
            }
        }
    }

    const finalVal = cash + calculateInvestedVal(holdings, allData, tradingDays[tradingDays.length - 1]);
    console.log(`MONTH_REPORT|${start_date}|${finalVal.toFixed(2)}|${reserve.toFixed(2)}`);
    return { finalVal, reserve, ledger };
}

// Utility functions
function calculateSMA(data, p) { return data.slice(-p).reduce((a, v) => a + v.c, 0) / p; }
function calculateStdDev(data, p, mean) { return Math.sqrt(data.slice(-p).reduce((a, v) => a + Math.pow(v.c - mean, 2), 0) / p); }
function calculateInvestedVal(holdings, allData, ts) {
    let v = 0;
    for (const t in holdings) {
        const bar = allData[t].find(b => b.t === ts);
        v += holdings[t].qty * (bar ? bar.c : holdings[t].costBasis);
    }
    return v;
}
function isLastTradingDayOfMonth(date, all) {
    const m = date.substring(0, 7);
    const mDays = all.filter(d => d.startsWith(m));
    return mDays[mDays.length - 1].startsWith(date);
}
async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

const config = JSON.parse(process.argv[2]);
runBacktest(config);
