const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function runJulyImprovedBacktest() {
    // July 2024 Trading Days
    const tradingDays = [
        "2024-07-01", "2024-07-02", "2024-07-03", "2024-07-05", "2024-07-08",
        "2024-07-09", "2024-07-10", "2024-07-11", "2024-07-12", "2024-07-15",
        "2024-07-16", "2024-07-17", "2024-07-18", "2024-07-19", "2024-07-22",
        "2024-07-23", "2024-07-24", "2024-07-25", "2024-07-26", "2024-07-29",
        "2024-07-30", "2024-07-31"
    ];

    let totalPortfolioValue = 80.89; // Starting from June's close
    const dailyStats = [];

    console.log(`Analyzing July 2024 with Improved Logic (Split-Adjusted & ATR Protection)...`);

    for (const day of tradingDays) {
        let dailyPnl = 0;
        let daySummary = { day, tickers: [] };

        for (const ticker of TICKERS) {
            const lookbackEnd = new Date(new Date(day).getTime() - (1 * 24 * 60 * 60 * 1000)).toISOString();
            // Fetch lookback with a buffer
            const history = await fetchAlpacaBars(ticker, '2024-05-01T00:00:00Z', lookbackEnd);
            
            if (history.length < 20) continue;

            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const lastClose = history[history.length - 1].c;
            
            // Calculate ATR-like Volatility Stop (Simplified: 2 * 20-day StdDev)
            const mean = sma20;
            const stdDev = Math.sqrt(window.reduce((acc, val) => acc + Math.pow(val.c - mean, 2), 0) / 20);
            const stopLoss = lastClose - (2 * stdDev);

            if (lastClose > sma20) {
                const actualDayData = await fetchAlpacaBars(ticker, day + 'T00:00:00Z', day + 'T23:59:59Z');
                if (actualDayData.length > 0) {
                    const actualClose = actualDayData[actualDayData.length - 1].c;
                    
                    // IMPROVEMENT: Split/Jump Check (If price changes > 50% in one day, ignore as data anomaly/split for now)
                    if (Math.abs((actualClose - lastClose) / lastClose) > 0.5) {
                        console.log(`Skipping ${ticker} on ${day} - Possible split/anomaly.`);
                        continue;
                    }

                    // IMPROVEMENT: Stop Loss Logic
                    const effectiveExit = actualClose < stopLoss ? stopLoss : actualClose;
                    const changePercent = (effectiveExit - lastClose) / lastClose;
                    
                    const positionSize = totalPortfolioValue / TICKERS.length;
                    const tradePnl = positionSize * changePercent;
                    
                    dailyPnl += tradePnl;
                    daySummary.tickers.push({ ticker, pnl: tradePnl.toFixed(2), change: (changePercent * 100).toFixed(2) + '%', exit: actualClose < stopLoss ? 'STOP_HIT' : 'CLOSE' });
                }
            }
        }

        totalPortfolioValue += dailyPnl;
        dailyStats.push({ day, pnl: dailyPnl.toFixed(2), total: totalPortfolioValue.toFixed(2), tickers: daySummary.tickers });

        await supabase.from('performance_metrics').insert({
            date: day,
            daily_pnl: dailyPnl,
            logic_version: 'SMA20_ATR_v2',
            notes: JSON.stringify(daySummary.tickers)
        });
    }

    console.log("JULY_REPORT_START");
    console.log(JSON.stringify(dailyStats, null, 2));
    console.log("JULY_REPORT_END");
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runJulyImprovedBacktest();
