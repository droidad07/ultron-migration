const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM"];
const START_CAPITAL = 100.0;

async function runBacktest() {
    console.log(`Starting historical backtest with $${START_CAPITAL} (Diversified Core)...`);
    
    for (const ticker of TICKERS) {
        try {
            console.log(`Fetching Alpaca data for ${ticker}...`);
            // Alpaca V2 historical bars
            const response = await axios.get(`https://data.alpaca.markets/v2/stocks/${ticker}/bars`, {
                params: {
                    start: '2024-01-01T00:00:00Z',
                    timeframe: '1Day',
                    adjustment: 'all'
                },
                headers: {
                    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
                    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
                }
            });
            
            const result = response.data.bars;
            if (!result || result.length < 20) {
                console.log(`Insufficient data for ${ticker}`);
                continue;
            }

            console.log(`Processing ${result.length} bars for ${ticker}...`);

            let position = 0; 
            for (let i = 20; i < result.length; i++) {
                const window = result.slice(i - 20, i);
                const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
                const currentClose = result[i].c;

                if (currentClose > sma20 && position === 0) {
                    position = 1;
                    await logTrade(ticker, 'buy', currentClose, result[i].t);
                } else if (currentClose < sma20 && position === 1) {
                    position = 0;
                    await logTrade(ticker, 'sell', currentClose, result[i].t);
                }
            }
        } catch (err) {
            console.error(`Error processing ${ticker}:`, err.response ? err.response.data : err.message);
        }
    }
    console.log("Backtest complete.");
}

async function logTrade(ticker, side, price, dateStr) {
    const { error } = await supabase.from('trades').insert({
        ticker: ticker,
        side: side,
        price: price,
        quantity: 0,
        strategy_name: 'Momentum_SMA20_Alpaca_v1',
        notes: `Backtest signal for $${ticker} on ${dateStr}`
    });
    if (error) console.error('Supabase Log Error:', error.message);
}

runBacktest();
