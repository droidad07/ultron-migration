const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function runSeptemberAggressiveBacktest() {
    const tradingDays = [
        "2024-09-03", "2024-09-04", "2024-09-05", "2024-09-06", "2024-09-09",
        "2024-09-10", "2024-09-11", "2024-09-12", "2024-09-13", "2024-09-16",
        "2024-09-17", "2024-09-18", "2024-09-19", "2024-09-20", "2024-09-23",
        "2024-09-24", "2024-09-25", "2024-09-26", "2024-09-27", "2024-09-30"
    ];

    let totalPortfolioValue = 89.76; // Theoretical balance after August recovery
    const dailyStats = [];

    console.log(`Analyzing September 2024: Aggressive Mode (Concentrated Position Sizing)...`);

    for (const day of tradingDays) {
        let dailyPnl = 0;
        let activeSignals = [];

        // Step 1: Identify Signals first
        for (const ticker of TICKERS) {
            const lookbackEnd = new Date(new Date(day).getTime() - (1 * 24 * 60 * 60 * 1000)).toISOString();
            const history = await fetchAlpacaBars(ticker, '2024-07-01T00:00:00Z', lookbackEnd);
            if (history.length < 20) continue;

            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const lastClose = history[history.length - 1].c;

            if (lastClose > sma20) {
                activeSignals.push({ ticker, lastClose, window });
            }
        }

        // Step 2: Aggressive Allocation
        // Instead of splitting capital 10 ways, we only split it among ACTIVE signals (max 4).
        // If only 2 stocks show momentum, they each get 50% of the portfolio. Higher risk, higher reward.
        const maxSlots = 4;
        const slotsToFill = Math.min(activeSignals.length, maxSlots);
        const positionSize = slotsToFill > 0 ? totalPortfolioValue / slotsToFill : 0;

        let daySummary = { day, tickers: [] };

        if (slotsToFill > 0) {
            for (let i = 0; i < slotsToFill; i++) {
                const { ticker, lastClose, window } = activeSignals[i];
                const actualDayData = await fetchAlpacaBars(ticker, day + 'T00:00:00Z', day + 'T23:59:59Z');
                
                if (actualDayData.length > 0) {
                    const actualClose = actualDayData[actualDayData.length - 1].c;
                    const changePercent = (actualClose - lastClose) / lastClose;
                    
                    // ATR Stop remains for safety
                    const mean = window.reduce((acc, val) => acc + val.c, 0) / 20;
                    const stdDev = Math.sqrt(window.reduce((acc, val) => acc + Math.pow(val.c - mean, 2), 0) / 20);
                    const stopLoss = lastClose - (1.5 * stdDev); // Tighter stop for aggressive mode

                    const effectiveExit = actualClose < stopLoss ? stopLoss : actualClose;
                    const tradePnl = positionSize * ((effectiveExit - lastClose) / lastClose);
                    
                    dailyPnl += tradePnl;
                    daySummary.tickers.push({ ticker, pnl: tradePnl.toFixed(2), exit: actualClose < stopLoss ? 'STOP_HIT' : 'CLOSE' });
                }
            }
        }

        totalPortfolioValue += dailyPnl;
        dailyStats.push({ day, pnl: dailyPnl.toFixed(2), total: totalPortfolioValue.toFixed(2), tickers: daySummary.tickers });

        await supabase.from('performance_metrics').insert({
            date: day,
            daily_pnl: dailyPnl,
            logic_version: 'Aggressive_Concentrated_v4',
            notes: JSON.stringify(daySummary.tickers)
        });
    }

    console.log("SEPT_REPORT_START");
    console.log(JSON.stringify(dailyStats, null, 2));
    console.log("SEPT_REPORT_END");
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runSeptemberAggressiveBacktest();
