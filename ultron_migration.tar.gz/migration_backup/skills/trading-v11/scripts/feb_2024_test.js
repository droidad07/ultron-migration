const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function runFebruaryWalkForward() {
    const portfolioStart = 104.50; // Starting from Jan close
    let portfolio = portfolioStart;
    const tradeLog = [];
    
    console.log(`Starting February 2024 "Walk-Forward" Deep Dive...`);

    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2023-12-01T00:00:00Z', '2024-03-01T23:59:59Z');
    }

    const firstTicker = TICKERS[0];
    const tradingDays = allData[firstTicker]
        .filter(b => b.t >= '2024-02-01T00:00:00Z' && b.t <= '2024-02-29T23:59:59Z')
        .map(b => b.t);

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        let activeSignals = [];

        for (const ticker of TICKERS) {
            const history = allData[ticker].filter(b => b.t < timestamp);
            if (history.length < 20) continue;

            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const lastClose = history[history.length - 1].c;

            if (lastClose > sma20) {
                const stdDev = Math.sqrt(window.reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
                activeSignals.push({ ticker, entry: lastClose, stop: lastClose - (1.5 * stdDev) });
            }
        }

        const signalsToTrade = activeSignals.slice(0, 4);
        const posSize = signalsToTrade.length > 0 ? portfolio / signalsToTrade.length : 0;

        for (const sig of signalsToTrade) {
            const dayBar = allData[sig.ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;

            const actualClose = dayBar.c;
            const qty = posSize / sig.entry;
            
            let exitPrice = actualClose;
            let status = "CLOSE";
            if (actualClose < sig.stop) {
                exitPrice = sig.stop;
                status = "STOP_HIT";
            }

            const pnl = qty * (exitPrice - sig.entry);
            portfolio += pnl;

            tradeLog.push({
                Date: dayStr,
                Ticker: sig.ticker,
                Action: "BUY_SELL",
                Qty: qty.toFixed(6),
                Entry_Price: sig.entry.toFixed(2),
                Exit_Price: exitPrice.toFixed(2),
                PnL: pnl.toFixed(2),
                Status: status,
                Reason: `SMA20 Momentum (${status})`
            });
        }
    }

    const csvHeader = "Date,Ticker,Action,Qty,Entry_Price,Exit_Price,PnL,Status,Reason";
    const csvRows = tradeLog.map(t => `${t.Date},${t.Ticker},${t.Action},${t.Qty},${t.Entry_Price},${t.Exit_Price},${t.PnL},${t.Status},"${t.Reason}"`);
    const csvContent = [csvHeader, ...csvRows].join('\n');
    
    const fileName = `Ultron_Feb2024_Fractional_Report.csv`;
    fs.writeFileSync(path.join(__dirname, fileName), csvContent);
    console.log(`REPORT_DONE:${fileName}`);
    console.log(`FINAL_BALANCE:${portfolio.toFixed(2)}`);
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runFebruaryWalkForward();
