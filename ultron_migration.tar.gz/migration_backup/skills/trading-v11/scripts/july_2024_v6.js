const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

function calculateRSI(prices, period = 14) {
    if (prices.length <= period) return 50;
    let gains = 0;
    let losses = 0;
    for (let i = 1; i <= period; i++) {
        const diff = prices[prices.length - i] - prices[prices.length - i - 1];
        if (diff >= 0) gains += diff;
        else losses -= diff;
    }
    const avgGain = gains / period;
    const avgLoss = losses / period;
    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
}

async function runJulyRSILedger() {
    // STARTING FROM JUNE CORRECTED CLOSE
    let cash = 173.55; 
    let holdings = {}; 
    const ledger = [];

    console.log(`Starting July 2024 "True Ledger" with RSI v6 Optimization...`);

    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2024-05-01T00:00:00Z', '2024-08-01T23:59:59Z');
    }

    const tradingDays = allData["NVDA"]
        .filter(b => b.t >= '2024-07-01T00:00:00Z' && b.t <= '2024-07-31T23:59:59Z')
        .map(b => b.t);

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        
        // 1. EXIT LOGIC
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;

            const currentPrice = dayBar.c;
            const history = allData[ticker].filter(b => b.t < timestamp);
            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const stdDev = Math.sqrt(window.reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
            const stopLoss = holdings[ticker].costBasis - (1.5 * stdDev);

            if (currentPrice < sma20 || currentPrice < stopLoss) {
                const sellQty = holdings[ticker].qty;
                const proceeds = sellQty * currentPrice;
                const pnl = proceeds - (sellQty * holdings[ticker].costBasis);
                cash += proceeds;
                
                await logToSupabase(dayStr, ticker, "SELL", currentPrice, sellQty, proceeds, pnl, cash, calculateHoldingsValue(holdings, allData, timestamp, ticker), currentPrice < stopLoss ? "STOP_HIT" : "MOMENTUM_LOSS");
                delete holdings[ticker];
            }
        }

        // 2. ENTRY LOGIC (with RSI Filter < 70)
        if (cash > 1.00) {
            let activeSignals = [];
            for (const ticker of TICKERS) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 20) continue;
                const window = history.slice(-20);
                const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
                const lastClose = history[history.length - 1].c;
                
                // RSI CALCULATION
                const closePrices = history.map(h => h.c);
                const rsi = calculateRSI(closePrices);

                // Strategy: Momentum (Price > SMA20) AND NOT OVERBOUGHT (RSI < 70)
                if (lastClose > sma20 && rsi < 70) {
                    activeSignals.push({ ticker, price: lastClose, rsi });
                }
            }

            const signalsToBuy = activeSignals.slice(0, 2); // Max 2 concentrated entries
            const maxSpend = cash / Math.max(1, signalsToBuy.length);

            for (const sig of signalsToBuy) {
                const spend = Math.min(cash, maxSpend);
                const qty = spend / sig.price;
                cash -= spend;
                holdings[sig.ticker] = { qty, costBasis: sig.price };
                await logToSupabase(dayStr, sig.ticker, "BUY", sig.price, qty, spend, 0, cash, calculateHoldingsValue(holdings, allData, timestamp), `SMA20_RSI(${sig.rsi.toFixed(1)})`);
            }
        }
    }
    const finalValue = cash + calculateHoldingsValue(holdings, allData, tradingDays[tradingDays.length-1]);
    console.log(`FINAL_BALANCE:${finalValue.toFixed(2)}`);
}

async function logToSupabase(date, ticker, side, price, qty, amount, pnl, cash, invested, reason) {
    await supabase.from('trades').insert({
        timestamp: new Date(date).toISOString(),
        ticker: ticker,
        side: side,
        price: price,
        quantity: qty,
        strategy_name: 'v6_RSI_Momentum',
        notes: JSON.stringify({ amount, pnl, cash_on_hand: cash, invested_value: invested, reason })
    });
}

function calculateHoldingsValue(holdings, allData, timestamp, excludeTicker = null) {
    let value = 0;
    for (const ticker in holdings) {
        if (ticker === excludeTicker) continue;
        const dayBar = allData[ticker].find(b => b.t === timestamp);
        if (dayBar) value += holdings[ticker].qty * dayBar.c;
        else value += holdings[ticker].qty * holdings[ticker].costBasis;
    }
    return value;
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runJulyRSILedger();
