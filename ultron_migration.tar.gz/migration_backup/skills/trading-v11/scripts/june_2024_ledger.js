const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function runJuneTrueLedgerBacktest() {
    // STARTING POSITION FROM MAY CLOSE:
    // Theoretical Value was $152.63. 
    // User requested to assume $0 cash and EVERYTHING invested.
    // We'll distribute that $152.63 across the holdings from May's end or simply start June by deploying it into June 1st signals.
    let cash = 0.00; 
    let holdings = {}; 
    const ledger = [];
    
    // Initial Seed: To simulate "Everything Invested", we first look at the state on June 1st.
    // However, since June 1st was a weekend, the first trading day is June 3rd.
    // We will initialize the portfolio value at $152.63.
    let currentPortfolioValue = 152.63;

    console.log(`Starting June 2024 "True Ledger" Deep Dive ($152.63 Initial Value - Fully Invested)...`);

    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2024-04-01T00:00:00Z', '2024-07-01T23:59:59Z');
    }

    const firstTicker = TICKERS[0];
    const tradingDays = allData[firstTicker]
        .filter(b => b.t >= '2024-06-01T00:00:00Z' && b.t <= '2024-06-30T23:59:59Z')
        .map(b => b.t);

    // Initial Deployment (Simulating "Everything Invested" on Day 1 based on May signals)
    const firstDay = tradingDays[0];
    let initialSignals = [];
    for (const ticker of TICKERS) {
        const history = allData[ticker].filter(b => b.t < firstDay);
        if (history.length < 20) continue;
        const window = history.slice(-20);
        const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
        const lastClose = history[history.length - 1].c;
        if (lastClose > sma20) initialSignals.push({ ticker, price: lastClose });
    }
    
    const topInitial = initialSignals.slice(0, 4);
    const initialPosSize = currentPortfolioValue / topInitial.length;
    for (const sig of topInitial) {
        holdings[sig.ticker] = { qty: initialPosSize / sig.price, costBasis: sig.price };
        ledger.push({
            Date: firstDay.split('T')[0],
            Ticker: sig.ticker,
            Action: "INITIAL_HOLDING",
            Price: sig.price.toFixed(2),
            Qty: holdings[sig.ticker].qty.toFixed(6),
            Amount: initialPosSize.toFixed(2),
            PnL: "0.00",
            Cash_On_Hand: "0.00",
            Invested_Value: currentPortfolioValue.toFixed(2),
            Reason: "Carried from May momentum"
        });
    }

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        
        // 1. EVALUATE EXITS (Sell logic)
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;

            const currentPrice = dayBar.c;
            const history = allData[ticker].filter(b => b.t < timestamp);
            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const stdDev = Math.sqrt(window.reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
            const stopLoss = holdings[ticker].costBasis - (1.5 * stdDev);

            // SPECIAL CASE: NVDA split handled (If price drops > 80% but it's NVDA in June, adjust)
            let isSplit = (ticker === 'NVDA' && dayStr === '2024-06-10');

            if ((currentPrice < sma20 || currentPrice < stopLoss) && !isSplit) {
                const sellQty = holdings[ticker].qty;
                const proceeds = sellQty * currentPrice;
                const pnl = proceeds - (sellQty * holdings[ticker].costBasis);
                
                cash += proceeds;
                ledger.push({
                    Date: dayStr,
                    Ticker: ticker,
                    Action: "SELL",
                    Price: currentPrice.toFixed(2),
                    Qty: sellQty.toFixed(6),
                    Amount: proceeds.toFixed(2),
                    PnL: pnl.toFixed(2),
                    Cash_On_Hand: cash.toFixed(2),
                    Invested_Value: calculateHoldingsValue(holdings, allData, timestamp, ticker).toFixed(2),
                    Reason: currentPrice < stopLoss ? "STOP_HIT" : "MOMENTUM_LOSS"
                });
                delete holdings[ticker];
            } else if (isSplit) {
                // Adjust for 10-for-1 split
                holdings[ticker].qty *= 10;
                holdings[ticker].costBasis /= 10;
                ledger.push({
                    Date: dayStr,
                    Ticker: ticker,
                    Action: "SPLIT_ADJUST",
                    Price: currentPrice.toFixed(2),
                    Qty: holdings[ticker].qty.toFixed(6),
                    Amount: "0.00",
                    PnL: "0.00",
                    Cash_On_Hand: cash.toFixed(2),
                    Invested_Value: calculateHoldingsValue(holdings, allData, timestamp).toFixed(2),
                    Reason: "10-for-1 Stock Split"
                });
            }
        }

        // 2. EVALUATE ENTRIES (Only if cash exists)
        if (cash > 1.00) {
            let activeSignals = [];
            for (const ticker of TICKERS) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 20) continue;
                const window = history.slice(-20);
                const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
                const lastClose = history[history.length - 1].c;
                if (lastClose > sma20) activeSignals.push({ ticker, price: lastClose });
            }

            const signalsToBuy = activeSignals.slice(0, 2);
            const maxSpend = cash / Math.max(1, signalsToBuy.length);

            for (const sig of signalsToBuy) {
                const spend = Math.min(cash, maxSpend);
                const qty = spend / sig.price;
                cash -= spend;
                holdings[sig.ticker] = { qty, costBasis: sig.price };
                ledger.push({
                    Date: dayStr,
                    Ticker: sig.ticker,
                    Action: "BUY",
                    Price: sig.price.toFixed(2),
                    Qty: qty.toFixed(6),
                    Amount: spend.toFixed(2),
                    PnL: "0.00",
                    Cash_On_Hand: cash.toFixed(2),
                    Invested_Value: calculateHoldingsValue(holdings, allData, timestamp).toFixed(2),
                    Reason: "SMA20_RE-ENTRY"
                });
            }
        }
    }

    const csvHeader = "Date,Ticker,Action,Price,Qty,Amount,PnL,Cash_On_Hand,Invested_Value,Reason";
    const csvRows = ledger.map(t => `${t.Date},${t.Ticker},${t.Action},${t.Price},${t.Qty},${t.Amount},${t.PnL},${t.Cash_On_Hand},${t.Invested_Value},"${t.Reason}"`);
    fs.writeFileSync(path.join(__dirname, 'Ultron_June2024_FullyInvested_Ledger.csv'), [csvHeader, ...csvRows].join('\n'));
    
    currentPortfolioValue = cash + calculateHoldingsValue(holdings, allData, tradingDays[tradingDays.length-1]);
    console.log(`FINAL_BALANCE:${currentPortfolioValue.toFixed(2)}`);
}

function calculateHoldingsValue(holdings, allData, timestamp, excludeTicker = null) {
    let value = 0;
    for (const ticker in holdings) {
        if (ticker === excludeTicker) continue;
        const dayBar = allData[ticker].find(b => b.t === timestamp);
        if (dayBar) value += holdings[ticker].qty * dayBar.c;
        else value += holdings[ticker].qty * holdings[ticker].costBasis;
    }
    return value;
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runJuneTrueLedgerBacktest();
