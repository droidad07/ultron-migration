const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function runMayTrueLedgerBacktest() {
    let cash = 127.32; 
    let holdings = {}; // { ticker: { qty, costBasis } }
    const ledger = [];
    
    console.log(`Starting May 2024 "True Ledger" Deep Dive ($127.32 Initial Cash)...`);

    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2024-03-01T00:00:00Z', '2024-06-01T23:59:59Z');
    }

    const firstTicker = TICKERS[0];
    const tradingDays = allData[firstTicker]
        .filter(b => b.t >= '2024-05-01T00:00:00Z' && b.t <= '2024-05-31T23:59:59Z')
        .map(b => b.t);

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        
        // 1. EVALUATE EXITS FIRST (Sell logic)
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;

            const currentPrice = dayBar.c;
            const history = allData[ticker].filter(b => b.t < timestamp);
            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const stdDev = Math.sqrt(window.reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
            const stopLoss = holdings[ticker].costBasis - (1.5 * stdDev);

            // Exit Condition: Price below SMA20 OR Stop Loss Hit
            if (currentPrice < sma20 || currentPrice < stopLoss) {
                const sellQty = holdings[ticker].qty;
                const proceeds = sellQty * currentPrice;
                const pnl = proceeds - (sellQty * holdings[ticker].costBasis);
                
                cash += proceeds;
                const reason = currentPrice < stopLoss ? "STOP_HIT" : "MOMENTUM_LOSS";
                
                ledger.push({
                    Date: dayStr,
                    Ticker: ticker,
                    Action: "SELL",
                    Price: currentPrice.toFixed(2),
                    Qty: sellQty.toFixed(6),
                    Amount: proceeds.toFixed(2),
                    PnL: pnl.toFixed(2),
                    Cash_On_Hand: cash.toFixed(2),
                    Invested_Value: calculateHoldingsValue(holdings, allData, timestamp).toFixed(2),
                    Reason: reason
                });
                delete holdings[ticker];
            }
        }

        // 2. EVALUATE ENTRIES (Buy logic)
        let activeSignals = [];
        for (const ticker of TICKERS) {
            if (holdings[ticker]) continue; // Already own it

            const history = allData[ticker].filter(b => b.t < timestamp);
            if (history.length < 20) continue;

            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const lastClose = history[history.length - 1].c;

            if (lastClose > sma20) {
                activeSignals.push({ ticker, price: lastClose });
            }
        }

        // Buy Top 2 signals if cash available (to keep concentration high)
        const signalsToBuy = activeSignals.slice(0, 2);
        const maxSpendPerStock = cash / 2; // Split remaining cash

        for (const sig of signalsToBuy) {
            if (cash <= 0.01) break;
            
            const spend = Math.min(cash, maxSpendPerStock);
            const qty = spend / sig.price;
            
            cash -= spend;
            holdings[sig.ticker] = { qty, costBasis: sig.price };

            ledger.push({
                Date: dayStr,
                Ticker: sig.ticker,
                Action: "BUY",
                Price: sig.price.toFixed(2),
                Qty: qty.toFixed(6),
                Amount: spend.toFixed(2),
                PnL: "0.00",
                Cash_On_Hand: cash.toFixed(2),
                Invested_Value: calculateHoldingsValue(holdings, allData, timestamp).toFixed(2),
                Reason: "SMA20_CROSSOVER"
            });
        }
    }

    const csvHeader = "Date,Ticker,Action,Price,Qty,Amount,PnL,Cash_On_Hand,Invested_Value,Reason";
    const csvRows = ledger.map(t => `${t.Date},${t.Ticker},${t.Action},${t.Price},${t.Qty},${t.Amount},${t.PnL},${t.Cash_On_Hand},${t.Invested_Value},"${t.Reason}"`);
    fs.writeFileSync(path.join(__dirname, 'Ultron_May2024_True_Ledger.csv'), [csvHeader, ...csvRows].join('\n'));
    console.log("FINAL_BALANCE:" + (cash + calculateHoldingsValue(holdings, allData, tradingDays[tradingDays.length-1])).toFixed(2));
}

function calculateHoldingsValue(holdings, allData, timestamp) {
    let value = 0;
    for (const ticker in holdings) {
        const dayBar = allData[ticker].find(b => b.t === timestamp);
        if (dayBar) value += holdings[ticker].qty * dayBar.c;
        else value += holdings[ticker].qty * holdings[ticker].costBasis;
    }
    return value;
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runMayTrueLedgerBacktest();
