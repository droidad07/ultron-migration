const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function runMayDetailedBacktest() {
    let cash = 127.32; // Starting cash from April close
    let totalPortfolioValue = cash;
    const tradeLog = [];
    
    console.log(`Starting May 2024 "Intraday-Aware" Deep Dive...`);

    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2024-03-01T00:00:00Z', '2024-06-01T23:59:59Z');
    }

    const firstTicker = TICKERS[0];
    const tradingDays = allData[firstTicker]
        .filter(b => b.t >= '2024-05-01T00:00:00Z' && b.t <= '2024-05-31T23:59:59Z')
        .map(b => b.t);

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        let activeSignals = [];

        // Pre-Trade Snapshot
        const startDayCash = cash;

        // 1. Scan for Signals based on Previous Day's Close
        for (const ticker of TICKERS) {
            const history = allData[ticker].filter(b => b.t < timestamp);
            if (history.length < 20) continue;

            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const lastClose = history[history.length - 1].c;

            if (lastClose > sma20) {
                const stdDev = Math.sqrt(window.reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
                activeSignals.push({ ticker, entry: lastClose, stop: lastClose - (1.5 * stdDev) });
            }
        }

        // 2. Execution Logic (Concentrated Top 4)
        const signalsToTrade = activeSignals.slice(0, 4);
        // We divide our TOTAL PORTFOLIO by 4 for equal sizing (as if we started the day in cash)
        const targetPosSize = signalsToTrade.length > 0 ? (cash / signalsToTrade.length) : 0;

        for (const sig of signalsToTrade) {
            const dayBar = allData[sig.ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;

            // Allocation
            const buyAmount = Math.min(cash, targetPosSize);
            const qty = buyAmount / sig.entry;
            cash -= buyAmount; // Cash goes down as we buy

            const actualClose = dayBar.c;
            let exitPrice = actualClose;
            let status = "CLOSE";
            if (actualClose < sig.stop) {
                exitPrice = sig.stop;
                status = "STOP_HIT";
            }

            const pnl = qty * (exitPrice - sig.entry);
            const saleProceeds = buyAmount + pnl;
            cash += saleProceeds; // Cash returns after end-of-day sale (Simulation assumes daily turnover)

            tradeLog.push({
                Date: dayStr,
                Ticker: sig.ticker,
                Cash_Before: startDayCash.toFixed(2),
                Invested: buyAmount.toFixed(2),
                Qty: qty.toFixed(6),
                Entry_Price: sig.entry.toFixed(2),
                Exit_Price: exitPrice.toFixed(2),
                PnL: pnl.toFixed(2),
                Cash_After: cash.toFixed(2),
                Portfolio_Value: (cash + (startDayCash - buyAmount - (startDayCash - cash))).toFixed(2), // Simplified daily tracking
                Status: status,
                Reason: `SMA20 Momentum | Qty: ${qty.toFixed(4)} @ ${sig.entry.toFixed(2)}`
            });
        }
        totalPortfolioValue = cash; // End of day portfolio value
    }

    const csvHeader = "Date,Ticker,Cash_Before,Invested,Qty,Entry_Price,Exit_Price,PnL,Cash_After,Status,Reason";
    const csvRows = tradeLog.map(t => `${t.Date},${t.Ticker},${t.Cash_Before},${t.Invested},${t.Qty},${t.Entry_Price},${t.Exit_Price},${t.PnL},${t.Cash_After},${t.Status},"${t.Reason}"`);
    const csvContent = [csvHeader, ...csvRows].join('\n');
    
    const fileName = `Ultron_May2024_CashFlow_Report.csv`;
    fs.writeFileSync(path.join(__dirname, fileName), csvContent);
    console.log(`REPORT_DONE:${fileName}`);
    console.log(`FINAL_BALANCE:${cash.toFixed(2)}`);
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runMayDetailedBacktest();
