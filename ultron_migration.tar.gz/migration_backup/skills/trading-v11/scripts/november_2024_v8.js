const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

function calculateRSI(prices, period = 14) {
    if (prices.length <= period) return 50;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) {
        const diff = prices[prices.length - i] - prices[prices.length - i - 1];
        if (diff >= 0) gains += diff; else losses -= diff;
    }
    const avgGain = gains / period, avgLoss = losses / period;
    return avgLoss === 0 ? 100 : 100 - (100 / (1 + (avgGain / avgLoss)));
}

async function runNovemberHarvestV8() {
    let cash = 0.00; 
    let holdings = {}; 
    const ledger = [];
    
    console.log(`Starting November 2024 with v8 (Profit-Harvesting) Engine...`);

    const allData = {};
    for (const ticker of TICKERS) {
        allData[ticker] = await fetchAlpacaBars(ticker, '2024-09-01T00:00:00Z', '2024-12-01T23:59:59Z');
    }

    const firstNovDay = '2024-11-01T04:00:00Z';
    const startPortfolioValue = 181.29; // From October close (post-harvest)

    // 1. Carryover holdings from October
    let carryoverSignals = [];
    for (const ticker of TICKERS) {
        const history = allData[ticker].filter(b => b.t < firstNovDay);
        if (history.length < 20) continue;
        const lastClose = history[history.length - 1].c;
        const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
        if (lastClose > sma20) carryoverSignals.push({ ticker, price: lastClose });
    }

    const topCarry = carryoverSignals.slice(0, 4);
    const initialPosSize = startPortfolioValue / (topCarry.length || 1);
    for (const sig of topCarry) {
        holdings[sig.ticker] = { qty: initialPosSize / sig.price, costBasis: sig.price };
        ledger.push({
            Date: "2024-11-01", Ticker: sig.ticker, Action: "CARRYOVER_HOLDING",
            Price: sig.price.toFixed(2), Qty: holdings[sig.ticker].qty.toFixed(6),
            Amount: initialPosSize.toFixed(2), PnL: "0.00", Cash_On_Hand: "0.00",
            Invested_Value: startPortfolioValue.toFixed(2), Reason: "Carried from Oct"
        });
    }

    const tradingDays = allData["NVDA"]
        .filter(b => b.t >= '2024-11-01T00:00:00Z' && b.t <= '2024-11-30T23:59:59Z')
        .map(b => b.t);

    for (const timestamp of tradingDays) {
        const dayStr = timestamp.split('T')[0];
        
        for (const ticker in holdings) {
            const dayBar = allData[ticker].find(b => b.t === timestamp);
            if (!dayBar) continue;

            const currentPrice = dayBar.c;
            const history = allData[ticker].filter(b => b.t < timestamp);
            const rsi = calculateRSI(history.map(h => h.c));
            const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
            const stdDev = Math.sqrt(history.slice(-20).reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
            const stopLoss = holdings[ticker].costBasis - (1.5 * stdDev);

            if (currentPrice < sma20 || currentPrice < stopLoss || rsi > 75) {
                const sellQty = holdings[ticker].qty;
                const proceeds = sellQty * currentPrice;
                const pnl = proceeds - (sellQty * holdings[ticker].costBasis);
                cash += proceeds;
                
                let reason = "MOMENTUM_LOSS";
                if (currentPrice < stopLoss) reason = "STOP_HIT";
                if (rsi > 75) reason = "PROFIT_TAKE_RSI";

                ledger.push({
                    Date: dayStr, Ticker: ticker, Action: "SELL", Price: currentPrice.toFixed(2),
                    Qty: sellQty.toFixed(6), Amount: proceeds.toFixed(2), PnL: pnl.toFixed(2),
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateHoldingsValue(holdings, allData, timestamp, ticker).toFixed(2),
                    Reason: reason
                });
                delete holdings[ticker];
            }
        }

        if (cash > 1.00) {
            let activeSignals = [];
            for (const ticker of TICKERS) {
                if (holdings[ticker]) continue;
                const history = allData[ticker].filter(b => b.t < timestamp);
                if (history.length < 20) continue;
                const lastClose = history[history.length - 1].c;
                const rsi = calculateRSI(history.map(h => h.c));
                const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;

                if ((lastClose > sma20 && rsi < 70) || (rsi < 35)) {
                    activeSignals.push({ ticker, price: lastClose, rsi, type: rsi < 35 ? "DIP" : "MOMENTUM" });
                }
            }
            const signalsToBuy = activeSignals.slice(0, 2);
            const maxSpend = cash / Math.max(1, signalsToBuy.length);
            for (const sig of signalsToBuy) {
                const spend = Math.min(cash, maxSpend);
                holdings[sig.ticker] = { qty: spend / sig.price, costBasis: sig.price };
                cash -= spend;
                ledger.push({
                    Date: dayStr, Ticker: sig.ticker, Action: "BUY", Price: sig.price.toFixed(2),
                    Qty: holdings[sig.ticker].qty.toFixed(6), Amount: spend.toFixed(2), PnL: "0.00",
                    Cash_On_Hand: cash.toFixed(2), Invested_Value: calculateHoldingsValue(holdings, allData, timestamp).toFixed(2),
                    Reason: `v8_${sig.type}_RSI(${sig.rsi.toFixed(1)})`
                });
            }
        }
    }

    const lastDay = tradingDays[tradingDays.length - 1];
    const finalGrossValue = cash + calculateHoldingsValue(holdings, allData, lastDay);
    let harvestAmount = 0;
    
    if (finalGrossValue > startPortfolioValue) {
        harvestAmount = (finalGrossValue - startPortfolioValue) * 0.50;
        const finalNetValue = finalGrossValue - harvestAmount;
        
        ledger.push({
            Date: "2024-11-30", Ticker: "PORTFOLIO", Action: "PROFIT_HARVEST",
            Price: "0.00", Qty: "0.00", Amount: harvestAmount.toFixed(2), PnL: "0.00",
            Cash_On_Hand: "RESERVE", Invested_Value: finalNetValue.toFixed(2),
            Reason: "50% Growth Locked to Cash"
        });
    }

    const csvHeader = "Date,Ticker,Action,Price,Qty,Amount,PnL,Cash_On_Hand,Invested_Value,Reason";
    const csvRows = ledger.map(t => `${t.Date},${t.Ticker},${t.Action},${t.Price},${t.Qty},${t.Amount},${t.PnL},${t.Cash_On_Hand},${t.Invested_Value},"${t.Reason}"`);
    fs.writeFileSync(path.join(__dirname, 'Ultron_Nov2024_v8_Harvest.csv'), [csvHeader, ...csvRows].join('\n'));
    
    console.log(`FINAL_VALUE_POST_HARVEST:${(finalGrossValue - (harvestAmount || 0)).toFixed(2)}`);
    console.log(`HARVESTED_CASH:${harvestAmount.toFixed(2)}`);
}

function calculateHoldingsValue(holdings, allData, timestamp, excludeTicker = null) {
    let value = 0;
    for (const ticker in holdings) {
        if (ticker === excludeTicker) continue;
        const dayBar = allData[ticker].find(b => b.t === timestamp);
        if (dayBar) value += holdings[ticker].qty * dayBar.c;
        else value += holdings[ticker].qty * (holdings[ticker].costBasis || 0);
    }
    return value;
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runNovemberHarvestV8();
