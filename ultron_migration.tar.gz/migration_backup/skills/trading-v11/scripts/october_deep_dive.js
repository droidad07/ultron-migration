const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function runOctoberDeepDive() {
    const tradingDays = [
        "2024-10-01", "2024-10-02", "2024-10-03", "2024-10-04", "2024-10-07",
        "2024-10-08", "2024-10-09", "2024-10-10", "2024-10-11", "2024-10-14"
    ];

    let portfolio = 103.85; 
    const tradeLog = [];

    console.log(`Analyzing October 2024: Deep-Dive Mode (Trade-by-Trade Logic)...`);

    for (const day of tradingDays) {
        let activeSignals = [];
        
        // 1. Scan for Signals
        for (const ticker of TICKERS) {
            const lookbackEnd = new Date(new Date(day).getTime() - (1 * 24 * 60 * 60 * 1000)).toISOString();
            const history = await fetchAlpacaBars(ticker, '2024-08-01T00:00:00Z', lookbackEnd);
            if (history.length < 20) continue;

            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const lastClose = history[history.length - 1].c;

            if (lastClose > sma20) {
                const mean = window.reduce((acc, val) => acc + val.c, 0) / 20;
                const stdDev = Math.sqrt(window.reduce((acc, val) => acc + Math.pow(val.c - mean, 2), 0) / 20);
                activeSignals.push({ ticker, entryPrice: lastClose, stopLoss: lastClose - (1.5 * stdDev), reason: "Price > SMA20 (Momentum)" });
            }
        }

        // 2. Concentrated Execution (Top 4)
        const topSignals = activeSignals.slice(0, 4);
        const positionSize = topSignals.length > 0 ? portfolio / topSignals.length : 0;

        for (const signal of topSignals) {
            const actualDayData = await fetchAlpacaBars(signal.ticker, day + 'T00:00:00Z', day + 'T23:59:59Z');
            if (actualDayData.length > 0) {
                const actualClose = actualDayData[actualDayData.length - 1].c;
                const quantity = Math.floor(positionSize / signal.entryPrice);
                
                let exitPrice = actualClose;
                let outcome = "CLOSE";
                let reason = "Daily momentum exit";

                if (actualClose < signal.stopLoss) {
                    exitPrice = signal.stopLoss;
                    outcome = "STOP_HIT";
                    reason = "Volatility threshold breached";
                }

                const pnl = quantity * (exitPrice - signal.entryPrice);
                portfolio += pnl;

                tradeLog.push({
                    day,
                    ticker: signal.ticker,
                    action: "BUY/SELL",
                    qty: quantity,
                    entry: signal.entryPrice.toFixed(2),
                    exit: exitPrice.toFixed(2),
                    pnl: pnl.toFixed(2),
                    reason: `${signal.reason} -> ${reason} (${outcome})`
                });
            }
        }
    }

    console.log("OCT_DEEP_DIVE_START");
    console.log(JSON.stringify(tradeLog, null, 2));
    console.log(`Final Portfolio: $${portfolio.toFixed(2)}`);
    console.log("OCT_DEEP_DIVE_END");
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runOctoberDeepDive();
