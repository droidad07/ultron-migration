const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM", "TSLA", "MSFT", "AMZN", "META"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function runFractionalOctober() {
    // Full October 2024 Trading Days
    const tradingDays = [
        "2024-10-01", "2024-10-02", "2024-10-03", "2024-10-04", "2024-10-07",
        "2024-10-08", "2024-10-09", "2024-10-10", "2024-10-11", "2024-10-14",
        "2024-10-15", "2024-10-16", "2024-10-17", "2024-10-18", "2024-10-21",
        "2024-10-22", "2024-10-23", "2024-10-24", "2024-10-25", "2024-10-28",
        "2024-10-29", "2024-10-30", "2024-10-31"
    ];

    let portfolio = 103.85; 
    const tradeLog = [];

    console.log(`Analyzing October 2024: FRACTIONAL Deep-Dive ($100 Budget)...`);

    for (const day of tradingDays) {
        let activeSignals = [];
        
        for (const ticker of TICKERS) {
            const lookbackEnd = new Date(new Date(day).getTime() - (1 * 24 * 60 * 60 * 1000)).toISOString();
            const history = await fetchAlpacaBars(ticker, '2024-08-01T00:00:00Z', lookbackEnd);
            if (history.length < 20) continue;

            const window = history.slice(-20);
            const sma20 = window.reduce((acc, val) => acc + val.c, 0) / 20;
            const lastClose = history[history.length - 1].c;

            if (lastClose > sma20) {
                const stdDev = Math.sqrt(window.reduce((acc, val) => acc + Math.pow(val.c - sma20, 2), 0) / 20);
                activeSignals.push({ ticker, entryPrice: lastClose, stopLoss: lastClose - (1.5 * stdDev) });
            }
        }

        const topSignals = activeSignals.slice(0, 4);
        const positionSize = topSignals.length > 0 ? portfolio / topSignals.length : 0;

        for (const signal of topSignals) {
            const actualDayData = await fetchAlpacaBars(signal.ticker, day + 'T00:00:00Z', day + 'T23:59:59Z');
            if (actualDayData.length > 0) {
                const actualClose = actualDayData[actualDayData.length - 1].c;
                
                // FRACTIONAL CALCULATION
                const fractionalQty = positionSize / signal.entryPrice;
                
                let exitPrice = actualClose;
                let outcome = "CLOSE";
                if (actualClose < signal.stopLoss) {
                    exitPrice = signal.stopLoss;
                    outcome = "STOP_HIT";
                }

                const pnl = fractionalQty * (exitPrice - signal.entryPrice);
                portfolio += pnl;

                tradeLog.push({
                    Date: day,
                    Ticker: signal.ticker,
                    Qty: fractionalQty.toFixed(4),
                    Entry: signal.entryPrice.toFixed(2),
                    Exit: exitPrice.toFixed(2),
                    PnL: pnl.toFixed(2),
                    Status: outcome
                });
            }
        }
    }

    // Output for Markdown Table
    console.log("MARKDOWN_START");
    console.log("| Date | Ticker | Qty | Entry | Exit | PnL | Status |");
    console.log("| :--- | :--- | :--- | :--- | :--- | :--- | :--- |");
    tradeLog.forEach(t => {
        console.log(`| ${t.Date} | ${t.Ticker} | ${t.Qty} | ${t.Entry} | ${t.Exit} | ${t.PnL} | ${t.Status} |`);
    });
    console.log(`\n**Final Portfolio Value: $${portfolio.toFixed(2)}**`);
    console.log("MARKDOWN_END");
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) { return []; }
}

runFractionalOctober();
