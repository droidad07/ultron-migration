const axios = require('axios');
require('dotenv').config();

const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function check2015() {
    const ticker = 'AAPL';
    // Test the middle of 2015 to see if any data exists at all
    const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=2015-06-01T04:00:00Z&limit=1`;
    try {
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        if (resp.data.bars && resp.data.bars.length > 0) {
            console.log(`DATA_FOUND: Earliest bar in record is ${resp.data.bars[0].t}`);
        } else {
            console.log("DATA_NOT_FOUND: 2015 appears to be outside of the Alpaca Free Tier range.");
        }
    } catch (e) {
        console.error(`API_ERROR: ${e.message}`);
    }
}

check2015();
