const { createClient } = require('@supabase/supabase-js');
const axios = require('axios');
require('dotenv').config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

const TICKERS = ["NVDA", "AAPL", "GOOGL", "PLTR", "JPM", "XOM"];
const ALPACA_HEADERS = {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY,
    'APCA-API-SECRET-KEY': process.env.ALPACA_SECRET_KEY
};

async function runSlidingWindowBacktest() {
    const testMonthStart = '2024-06-01';
    const testMonthEnd = '2024-07-01';
    
    // Generate array of trading days in June 2024 (simplified)
    const tradingDays = [
        "2024-06-03", "2024-06-04", "2024-06-05", "2024-06-06", "2024-06-07",
        "2024-06-10", "2024-06-11", "2024-06-12", "2024-06-13", "2024-06-14",
        "2024-06-17", "2024-06-18", "2024-06-20", "2024-06-21", "2024-06-24",
        "2024-06-25", "2024-06-26", "2024-06-27", "2024-06-28"
    ];

    console.log(`Starting Out-of-Sample "Walk-Forward" Testing for June 2024...`);

    for (const day of tradingDays) {
        console.log(`--- Testing Day: ${day} ---`);
        
        for (const ticker of TICKERS) {
            // 1. Fetch "Previous" Data (Lookback: 50 days before the test day)
            const lookbackStart = new Date(new Date(day).getTime() - (60 * 24 * 60 * 60 * 1000)).toISOString();
            const lookbackEnd = new Date(new Date(day).getTime() - (1 * 24 * 60 * 60 * 1000)).toISOString();
            
            const history = await fetchAlpacaBars(ticker, lookbackStart, lookbackEnd);
            
            if (history.length < 20) continue;

            // 2. Strategy Decision (Blind to the future)
            const sma20 = history.slice(-20).reduce((acc, val) => acc + val.c, 0) / 20;
            const lastClose = history[history.length - 1].c;
            const decision = lastClose > sma20 ? 'buy' : 'hold';

            // 3. Peak into the "Future" (The actual day we are testing)
            const actualDayData = await fetchAlpacaBars(ticker, day + 'T00:00:00Z', day + 'T23:59:59Z');
            if (actualDayData.length === 0) continue;

            const actualClose = actualDayData[actualDayData.length - 1].c;
            const result = decision === 'buy' ? (actualClose > lastClose ? 'WIN' : 'LOSS') : 'STAYED_OUT';

            // 4. Record the outcome
            await supabase.from('trades').insert({
                ticker: ticker,
                side: decision,
                price: actualClose,
                strategy_name: 'Walk_Forward_v1',
                notes: `Test Day: ${day} | Decision: ${decision} | Result: ${result} | Entry: ${lastClose} | Exit: ${actualClose}`
            });
        }
    }
    console.log("Walk-forward test complete. Performance logged to Supabase.");
}

async function fetchAlpacaBars(ticker, start, end) {
    try {
        const url = `https://data.alpaca.markets/v2/stocks/${ticker}/bars?timeframe=1Day&start=${start}&end=${end}`;
        const resp = await axios.get(url, { headers: ALPACA_HEADERS });
        return resp.data.bars || [];
    } catch (e) {
        return [];
    }
}

runSlidingWindowBacktest();
